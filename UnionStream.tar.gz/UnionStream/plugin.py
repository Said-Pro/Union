# -*- coding: utf-8 -*-
# ============================================================
#  Union Stream IPTV – plugin.py
#  Dossier : /usr/lib/enigma2/python/Plugins/Extensions/UnionStream/
#  Compatible Python 3 (OpenATV / OpenPLi / DreamOS)
#  Auteur : Said M.S  |  Version : 3.2.5
# ============================================================
#
#  Version avec skin intégré (pas de fichier skin.xml externe)
#  Add : Player plein écran UnionStreamPlayer avec OSD
#  CORRIGÉ : fond d'écran transparent pour laisser la vidéo visible
# ============================================================

import os
import json
import threading
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from enigma import eTimer, eServiceReference
try:
    from enigma import eCallInMainThread as _eCall
except ImportError:
    def _eCall(fn, *a): fn(*a)
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.MenuList import MenuList
from Components.ConfigList import ConfigListScreen
from Components.config import (
    config, ConfigSubsection,
    ConfigText, ConfigInteger, ConfigYesNo,
    ConfigSelection, ConfigPassword,
    getConfigListEntry,
)
from Plugins.Plugin import PluginDescriptor

# VLC supprime - Players natifs Enigma2 utilises

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
USERDATA = os.path.join(PLUGIN_PATH, "userdata")
FAV_FILE     = os.path.join(USERDATA, "favorites.json")
EPG_FILE     = os.path.join(USERDATA, "epg.xml.gz")
SERVERS_FILE = os.path.join(USERDATA, "servers.json")
os.makedirs(USERDATA, exist_ok=True)

_cfg_ready = False

def _init_config():
    global _cfg_ready
    if _cfg_ready:
        return
    if not hasattr(config, "plugins"):
        return
    if not hasattr(config.plugins, "UnionStream"):
        config.plugins.UnionStream = ConfigSubsection()
    p = config.plugins.UnionStream
    if not hasattr(p, "server_url"):
        p.server_url = ConfigText(default="http://mag.example.com:8080/stalker_portal")
        p.server_type = ConfigSelection(choices=["STALKER","M3U","Xtream"], default="STALKER")
        p.username = ConfigText(default="user")
        p.password = ConfigPassword(default="")
        p.mac_address = ConfigText(default="00:1A:79:XX:XX:XX")
        p.player = ConfigSelection(choices=["DVB","IPTV","GStreamer","ExtePlayer"], default="IPTV")
        p.buffer_time = ConfigInteger(default=4, limits=(1,30))
        p.hw_decode = ConfigYesNo(default=True)
        p.reconnect = ConfigYesNo(default=True)
        p.reconnect_tries = ConfigInteger(default=3, limits=(1,10))
        p.epg_url = ConfigText(default="http://epg.example.com/xmltv.xml.gz")
        p.epg_enabled = ConfigYesNo(default=True)
        p.epg_days = ConfigInteger(default=3, limits=(1,7))
        p.theme = ConfigSelection(choices=["blue","cyan","green","purple"], default="blue")
        p.animations = ConfigYesNo(default=True)
    _cfg_ready = True

def cfg():
    return getattr(getattr(config, "plugins", None), "UnionStream", None)

# Categories et chaines chargees dynamiquement depuis le serveur actif
CATEGORIES = [{"id":"all","name":"All (0)","count":0}]

CHANNELS = []

# VOD et Series : chargement dynamique depuis le serveur actif
VOD_LIST        = []   # rempli par _vod_load_*
VOD_CATEGORIES  = [{"id": "all", "name": "Toutes les categories", "count": 0}]
SERIES_LIST     = []   # rempli par _series_load_*
SERIES_CATEGORIES = [{"id": "all", "name": "Toutes les series", "count": 0}]

_SERVERS_DEFAULT = [
    {"name":"mag (STALKER)", "url":"http://mag.example.com:8080/stalker_portal", "type":"STALKER", "active":True},
    {"name":"m3u Premium",   "url":"http://m3u.example.com/get.php?u=user&p=pass","type":"M3U",    "active":False},
    {"name":"Xtream Codes",  "url":"http://xtream.example.com:25461",             "type":"Xtream", "active":False},
]

def load_servers():
    global SERVERS_DB
    try:
        with open(SERVERS_FILE, "r", encoding="utf-8") as f:
            SERVERS_DB = json.load(f)
    except Exception:
        SERVERS_DB = list(_SERVERS_DEFAULT)

def save_servers():
    try:
        with open(SERVERS_FILE, "w", encoding="utf-8") as f:
            json.dump(SERVERS_DB, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("[UnionStream] save_servers:", e)

load_servers()  # chargement au demarrage

def load_favorites():
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except Exception:
        return set()

def save_favorites(favs):
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump(list(favs), f)
    except Exception as e:
        print("[UnionStream] save_favorites:", e)


def channels_for_cat(cat_id):
    if cat_id == "all":
        return list(CHANNELS)
    cid = str(cat_id).strip()
    return [c for c in CHANNELS if str(c.get("cat", "")).strip() == cid]

# ══════════════════════════════════════════════════════════════════════════════
#  MOTEUR DE CHARGEMENT SERVEUR  -  STALKER / Xtream / M3U
# ══════════════════════════════════════════════════════════════════════════════

def _active_server():
    return next((s for s in SERVERS_DB if s.get("active")), None)

def _stalker_token(base_url, mac):
    try:
        url = "%s/server/load.php?type=stb&action=handshake&token=&JsHttpRequest=1-xml" % base_url.rstrip("/")
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0",
            "Referer":    base_url,
            "Cookie":     "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
        })
        data = json.loads(urlopen(req, timeout=10).read().decode("utf-8", errors="replace"))
        return data.get("js", {}).get("token", "")
    except Exception as e:
        print("[UnionStream] stalker token:", e)
        return ""

def _stalker_load_categories(base_url, mac, token):
    global CATEGORIES
    try:
        url = "%s/server/load.php?type=itv&action=get_genres&JsHttpRequest=1-xml" % base_url.rstrip("/")
        req = Request(url, headers={
            "User-Agent":    "Mozilla/5.0",
            "Referer":       base_url,
            "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
            "Authorization": "Bearer %s" % token,
        })
        data = json.loads(urlopen(req, timeout=10).read().decode("utf-8", errors="replace"))
        genres = data.get("js", [])
        cats = [{"id": "all", "name": "All", "count": 0}]
        for g in genres:
            cats.append({
                "id":    str(g.get("id", g.get("alias", ""))),
                "name":  g.get("title", g.get("name", "?")),
                "count": int(g.get("cnt", 0)),
            })
        CATEGORIES = cats
        return True
    except Exception as e:
        print("[UnionStream] stalker genres:", e)
        return False

def _stalker_load_channels(base_url, mac, token, genre_id="*"):
    global CHANNELS
    try:
        page = 1
        all_chs = []
        gid = "*" if genre_id == "all" else genre_id
        while True:
            url = ("%s/server/load.php?type=itv&action=get_ordered_list"
                   "&genre=%s&force_ch_link_check=&fav=0&sortby=number&p=%d"
                   "&JsHttpRequest=1-xml") % (base_url.rstrip("/"), gid, page)
            req = Request(url, headers={
                "User-Agent":    "Mozilla/5.0",
                "Referer":       base_url,
                "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
                "Authorization": "Bearer %s" % token,
            })
            data = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
            js   = data.get("js", {})
            rows = js.get("data", [])
            if not rows:
                break
            for ch in rows:
                cmd = ch.get("cmd", "")
                stream_url = cmd.replace("ffmpeg ", "").strip()
                cat = genre_id if genre_id != "all" else "all"
                all_chs.append({
                    "num":  len(all_chs) + 1,
                    "name": ch.get("name", "?"),
                    "url":  stream_url,
                    "cat":  cat,
                    "prog": ch.get("epg_now", {}).get("name", "") if isinstance(ch.get("epg_now"), dict) else "",
                    "t1":   "",
                    "t2":   "",
                    "pct":  0,
                })
            total = int(js.get("total_items", 0))
            if len(all_chs) >= total or not rows:
                break
            page += 1
            if page > 50:
                break
        CHANNELS = all_chs
        return True
    except Exception as e:
        print("[UnionStream] stalker channels:", e)
        return False

def _xtream_load_categories(base_url, username, password):
    global CATEGORIES
    try:
        url = "%s/player_api.php?username=%s&password=%s&action=get_live_categories" % (
            base_url.rstrip("/"), username, password)
        data = json.loads(urlopen(Request(url, headers={"User-Agent":"UnionStream/3.2"}),
                                  timeout=10).read().decode("utf-8", errors="replace"))
        cats = [{"id": "all", "name": "All", "count": 0}]
        for c in data:
            cats.append({
                "id":    str(c.get("category_id", "")),
                "name":  c.get("category_name", "?"),
                "count": 0,
            })
        CATEGORIES = cats
        return True
    except Exception as e:
        print("[UnionStream] xtream categories:", e)
        return False

def _xtream_load_channels(base_url, username, password, cat_id="all"):
    """
    Charge TOUTES les chaines Live depuis Xtream (ignore cat_id cote serveur).
    Le filtrage par categorie se fait localement via channels_for_cat().
    Raison : beaucoup de Servers ignorent le parametre category_id et renvoient
    toutes les chaines avec leur vrai category_id — le filtre local est plus fiable.
    """
    global CHANNELS
    try:
        # Toujours charger tout — jamais de filtre cote serveur
        url = "%s/player_api.php?username=%s&password=%s&action=get_live_streams" % (
            base_url.rstrip("/"), username, password)
        raw  = urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0 (SmartTV)"}),
                       timeout=20).read()

        # Detecter page HTML d erreur
        if raw[:50].lower().strip().startswith(b"<!") or raw[:50].lower().strip().startswith(b"<html"):
            print("[UnionStream] xtream channels: reponse HTML (credentials invalides ?)")
            return False

        data = json.loads(raw.decode("utf-8", errors="replace"))

        # Certains Servers encapsulent dans {"data":[...]}
        if isinstance(data, dict):
            data = data.get("data", data.get("streams", []))
        if not isinstance(data, list):
            print("[UnionStream] xtream channels: reponse inattendue type=%s" % type(data).__name__)
            return False

        chs        = []
        cat_counts = {}
        base        = base_url.rstrip("/")

        for i, ch in enumerate(data):
            sid = ch.get("stream_id", i + 1)

            # URL du flux : direct_source > /live/u/p/ID.ext > /live/u/p/ID
            direct = (ch.get("direct_source") or "").strip()
            if direct.startswith("http"):
                stream_url = direct
            else:
                ext = (ch.get("container_extension") or "ts").strip().lstrip(".")
                if ext:
                    stream_url = "%s/live/%s/%s/%s.%s" % (base, username, password, sid, ext)
                else:
                    stream_url = "%s/live/%s/%s/%s" % (base, username, password, sid)

            # Normaliser category_id en str propre
            raw_cat = ch.get("category_id")
            cat = str(raw_cat).strip() if raw_cat is not None else "0"

            chs.append({
                "num":  i + 1,
                "name": (ch.get("name") or "?").strip(),
                "url":  stream_url,
                "cat":  cat,
                "prog": "",
                "t1":   "",
                "t2":   "",
                "pct":  0,
            })
            cat_counts[cat] = cat_counts.get(cat, 0) + 1

        CHANNELS = chs

        # Mettre a jour les compteurs dans CATEGORIES
        for cat in CATEGORIES:
            cid = str(cat["id"]).strip()
            if cid == "all":
                cat["count"] = len(chs)
            else:
                cat["count"] = cat_counts.get(cid, 0)

        print("[UnionStream] xtream: %d chaines chargees, %d categories remplies" % (
            len(chs), sum(1 for c in cat_counts.values() if c > 0)))
        return True

    except Exception as e:
        print("[UnionStream] xtream channels ERREUR:", e)
        return False

def _m3u_load(url_or_file):
    global CATEGORIES, CHANNELS
    import re as _re
    try:
        if url_or_file.startswith("http"):
            raw = urlopen(Request(url_or_file, headers={"User-Agent":"UnionStream/3.2"}),
                          timeout=20).read().decode("utf-8", errors="replace")
        else:
            with open(url_or_file, "r", encoding="utf-8", errors="replace") as fh:
                raw = fh.read()
        lines  = raw.splitlines()
        chs    = []
        groups = {}
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith("#EXTINF"):
                name  = line.split(",", 1)[-1].strip() if "," in line else "?"
                group = ""
                m = _re.search(r'group-title="([^"]*)"', line)
                if m:
                    group = m.group(1).strip()
                m2 = _re.search(r'tvg-name="([^"]*)"', line)
                if m2 and m2.group(1).strip():
                    name = m2.group(1).strip()
                i += 1
                while i < len(lines) and not lines[i].strip():
                    i += 1
                if i < len(lines):
                    stream_url = lines[i].strip()
                    if stream_url and not stream_url.startswith("#"):
                        cat_id = _re.sub(r"[^a-z0-9_]", "_", group.lower())[:32] if group else "other"
                        if group and group not in groups:
                            groups[group] = cat_id
                        chs.append({
                            "num":  len(chs) + 1,
                            "name": name,
                            "url":  stream_url,
                            "cat":  cat_id,
                            "prog": "",
                            "t1":   "",
                            "t2":   "",
                            "pct":  0,
                        })
            i += 1
        cat_counts = {}
        for ch in chs:
            cat_counts[ch["cat"]] = cat_counts.get(ch["cat"], 0) + 1
        cats = [{"id": "all", "name": "All (%d)" % len(chs), "count": len(chs)}]
        for gname, cid in sorted(groups.items()):
            cats.append({"id": cid, "name": gname, "count": cat_counts.get(cid, 0)})
        CATEGORIES = cats
        CHANNELS   = chs
        return True
    except Exception as e:
        print("[UnionStream] m3u load:", e)
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  CHARGEMENT VOD  (Stalker / Xtream)
# ══════════════════════════════════════════════════════════════════════════════

def _stalker_load_vod_cats(base_url, mac, token):
    global VOD_CATEGORIES
    try:
        url = "%s/server/load.php?type=vod&action=get_categories&JsHttpRequest=1-xml" % base_url.rstrip("/")
        req = Request(url, headers={
            "User-Agent":    "Mozilla/5.0",
            "Referer":       base_url,
            "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
            "Authorization": "Bearer %s" % token,
        })
        data = json.loads(urlopen(req, timeout=10).read().decode("utf-8", errors="replace"))
        raw  = data.get("js", [])
        if isinstance(raw, dict):
            raw = raw.get("data", [])
        cats = [{"id": "all", "name": "Toutes les categories", "count": 0}]
        for c in (raw if isinstance(raw, list) else []):
            if isinstance(c, dict):
                cats.append({
                    "id":    str(c.get("id", c.get("category_id", ""))),
                    "name":  c.get("title", c.get("category_name", c.get("name", "?"))),
                    "count": int(c.get("cnt", 0)),
                })
        VOD_CATEGORIES = cats
        return True
    except Exception as e:
        print("[UnionStream] stalker vod cats:", e)
        return False

def _stalker_load_vod_page(base_url, mac, token, cat_id="all", page=1):
    global VOD_LIST
    try:
        params = {"type": "vod", "action": "get_ordered_list",
                  "p": str(page), "sortby": "name", "JsHttpRequest": "1-xml"}
        if cat_id and cat_id != "all":
            params["category"] = str(cat_id)
        url = base_url.rstrip("/") + "/server/load.php?" + "&".join(
            "%s=%s" % (k, v) for k, v in params.items())
        req = Request(url, headers={
            "User-Agent":    "Mozilla/5.0",
            "Referer":       base_url,
            "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
            "Authorization": "Bearer %s" % token,
        })
        data = json.loads(urlopen(req, timeout=20).read().decode("utf-8", errors="replace"))
        js   = data.get("js", {})
        if isinstance(js, dict):
            items     = js.get("data", js.get("movies", []))
            total     = int(js.get("total_items", len(items)))
            max_page  = int(js.get("max_page", 1))
        elif isinstance(js, list):
            items, total, max_page = js, len(js), 1
        else:
            items, total, max_page = [], 0, 1
        VOD_LIST = items
        return True, total, max_page
    except Exception as e:
        print("[UnionStream] stalker vod page:", e)
        return False, 0, 1

def _xtream_load_vod(base_url, username, password):
    """
    Charge TOUTES les categories VOD + TOUS les films en une seule passe.
    Principe identique a _xtream_load_channels : jamais de filtre category_id
    cote serveur — filtrage local via vod_for_cat().
    """
    global VOD_LIST, VOD_CATEGORIES
    try:
        base = base_url.rstrip("/")

        # 1. Categories
        url_c = "%s/player_api.php?username=%s&password=%s&action=get_vod_categories" % (
            base, username, password)
        raw_c = urlopen(Request(url_c, headers={"User-Agent": "Mozilla/5.0 (SmartTV)"}),
                        timeout=15).read()
        data_c = json.loads(raw_c.decode("utf-8", errors="replace"))
        if isinstance(data_c, dict):
            data_c = data_c.get("data", data_c.get("categories", []))
        if not isinstance(data_c, list):
            data_c = []
        cats = [{"id": "all", "name": "Toutes les categories", "count": 0}]
        for c in data_c:
            if isinstance(c, dict):
                cid = str(c.get("category_id", c.get("id", ""))).strip()
                if cid:
                    cats.append({
                        "id":    cid,
                        "name":  c.get("category_name", c.get("name", "?")).strip(),
                        "count": 0,
                    })
        VOD_CATEGORIES = cats

        # 2. Tous les films — sans filtre category_id (meme principe que get_live_streams)
        url_v = "%s/player_api.php?username=%s&password=%s&action=get_vod_streams" % (
            base, username, password)
        raw_v = urlopen(Request(url_v, headers={"User-Agent": "Mozilla/5.0 (SmartTV)"}),
                        timeout=30).read()
        if raw_v[:80].lower().strip().startswith(b"<!") or raw_v[:80].lower().strip().startswith(b"<html"):
            print("[UnionStream] xtream vod: reponse HTML (credentials ?)")
            return False
        all_m = json.loads(raw_v.decode("utf-8", errors="replace"))
        if isinstance(all_m, dict):
            all_m = all_m.get("data", all_m.get("streams", []))
        if not isinstance(all_m, list):
            all_m = []

        cat_counts = {}
        for m in all_m:
            if not isinstance(m, dict):
                continue
            # Normaliser category_id en str (identique a _xtream_load_channels)
            raw_cat  = m.get("category_id")
            m["_cat"] = str(raw_cat).strip() if raw_cat is not None else "0"
            # Precalculer l URL du film
            sid = m.get("stream_id", m.get("video_id", ""))
            ext = (m.get("container_extension") or "mp4").strip().lstrip(".")
            m["_url"] = "%s/movie/%s/%s/%s.%s" % (base, username, password, sid, ext)
            cat_counts[m["_cat"]] = cat_counts.get(m["_cat"], 0) + 1

        VOD_LIST = [m for m in all_m if isinstance(m, dict)]

        # Mettre a jour les compteurs
        for cat in VOD_CATEGORIES:
            cid = str(cat["id"]).strip()
            if cid == "all":
                cat["count"] = len(VOD_LIST)
            else:
                cat["count"] = cat_counts.get(cid, 0)

        print("[UnionStream] xtream vod: %d films, %d categories" % (len(VOD_LIST), len(VOD_CATEGORIES)-1))
        return True
    except Exception as e:
        print("[UnionStream] xtream vod ERREUR:", e)
        return False

def vod_for_cat(cat_id):
    """Filtre VOD_LIST par categorie (normalisation str, identique a channels_for_cat)."""
    if cat_id == "all":
        return list(VOD_LIST)
    cid = str(cat_id).strip()
    return [v for v in VOD_LIST if str(v.get("_cat", v.get("category_id", ""))).strip() == cid]

def load_vod_data(on_done=None):
    """Charge cats + films VOD depuis le serveur actif en thread."""
    srv = _active_server()
    if not srv:
        if on_done:
            on_done(False, "Aucun serveur actif.")
        return

    def _worker():
        t   = srv.get("type", "")
        url = srv.get("url", "").strip()
        ok  = False
        msg = ""
        try:
            if t == "STALKER":
                mac   = srv.get("mac", "00:1A:79:00:00:00")
                token = _stalker_token(url, mac)
                if token:
                    ok  = _stalker_load_vod_cats(url, mac, token)
                    msg = ("%d categories VOD" % (len(VOD_CATEGORIES)-1)) if ok else "Erreur cats VOD Stalker"
                else:
                    msg = "Echec auth Stalker"
            elif t == "Xtream":
                usr = srv.get("user", "").strip()
                pwd = srv.get("pass", "").strip()
                ok  = _xtream_load_vod(url, usr, pwd)
                msg = ("%d films, %d categories" % (len(VOD_LIST), len(VOD_CATEGORIES)-1)) if ok else "Erreur VOD Xtream"
            else:
                msg = "VOD non disponible pour M3U"
        except Exception as e:
            msg = str(e)
        if on_done:
            on_done(ok, msg)

    threading.Thread(target=_worker, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
#  CHARGEMENT SERIES  (Stalker / Xtream)
# ══════════════════════════════════════════════════════════════════════════════

def _stalker_load_series_cats(base_url, mac, token):
    global SERIES_CATEGORIES
    try:
        url = "%s/server/load.php?type=series&action=get_categories&JsHttpRequest=1-xml" % base_url.rstrip("/")
        req = Request(url, headers={
            "User-Agent":    "Mozilla/5.0",
            "Referer":       base_url,
            "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
            "Authorization": "Bearer %s" % token,
        })
        data = json.loads(urlopen(req, timeout=10).read().decode("utf-8", errors="replace"))
        raw  = data.get("js", [])
        if isinstance(raw, dict):
            raw = raw.get("data", [])
        cats = [{"id": "all", "name": "Toutes les series", "count": 0}]
        for c in (raw if isinstance(raw, list) else []):
            if isinstance(c, dict):
                cats.append({
                    "id":    str(c.get("id", c.get("category_id", ""))),
                    "name":  c.get("title", c.get("category_name", c.get("name", "?"))),
                    "count": int(c.get("cnt", 0)),
                })
        SERIES_CATEGORIES = cats
        return True
    except Exception as e:
        print("[UnionStream] stalker series cats:", e)
        return False

def _stalker_load_series_page(base_url, mac, token, cat_id="all", page=1):
    global SERIES_LIST
    try:
        params = {"type": "series", "action": "get_ordered_list",
                  "p": str(page), "JsHttpRequest": "1-xml"}
        if cat_id and cat_id != "all":
            params["category"] = str(cat_id)
        url = base_url.rstrip("/") + "/server/load.php?" + "&".join(
            "%s=%s" % (k, v) for k, v in params.items())
        req = Request(url, headers={
            "User-Agent":    "Mozilla/5.0",
            "Referer":       base_url,
            "Cookie":        "mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
            "Authorization": "Bearer %s" % token,
        })
        data  = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
        js    = data.get("js", {})
        if isinstance(js, dict):
            items     = js.get("data", js.get("movies", []))
            total     = int(js.get("total_items", len(items)))
            max_page  = int(js.get("max_page", 1))
        elif isinstance(js, list):
            items, total, max_page = js, len(js), 1
        else:
            items, total, max_page = [], 0, 1
        SERIES_LIST = items
        return True, total, max_page
    except Exception as e:
        print("[UnionStream] stalker series page:", e)
        return False, 0, 1

def _xtream_load_series(base_url, username, password):
    """
    Charge TOUTES les categories Series + TOUTES les series en une seule passe.
    Meme principe que _xtream_load_vod / _xtream_load_channels.
    """
    global SERIES_LIST, SERIES_CATEGORIES
    try:
        base = base_url.rstrip("/")

        # 1. Categories
        url_c = "%s/player_api.php?username=%s&password=%s&action=get_series_categories" % (
            base, username, password)
        raw_c  = urlopen(Request(url_c, headers={"User-Agent": "Mozilla/5.0 (SmartTV)"}),
                         timeout=15).read()
        data_c = json.loads(raw_c.decode("utf-8", errors="replace"))
        if isinstance(data_c, dict):
            data_c = data_c.get("data", data_c.get("categories", []))
        if not isinstance(data_c, list):
            data_c = []
        cats = [{"id": "all", "name": "Toutes les series", "count": 0}]
        for c in data_c:
            if isinstance(c, dict):
                cid = str(c.get("category_id", c.get("id", ""))).strip()
                if cid:
                    cats.append({
                        "id":    cid,
                        "name":  c.get("category_name", c.get("name", "?")).strip(),
                        "count": 0,
                    })
        SERIES_CATEGORIES = cats

        # 2. Toutes les series — sans filtre category_id
        url_s = "%s/player_api.php?username=%s&password=%s&action=get_series" % (
            base, username, password)
        raw_s = urlopen(Request(url_s, headers={"User-Agent": "Mozilla/5.0 (SmartTV)"}),
                        timeout=30).read()
        if raw_s[:80].lower().strip().startswith(b"<!") or raw_s[:80].lower().strip().startswith(b"<html"):
            print("[UnionStream] xtream series: reponse HTML (credentials ?)")
            return False
        all_s = json.loads(raw_s.decode("utf-8", errors="replace"))
        if isinstance(all_s, dict):
            all_s = all_s.get("data", all_s.get("series", []))
        if not isinstance(all_s, list):
            all_s = []

        cat_counts = {}
        for s in all_s:
            if not isinstance(s, dict):
                continue
            raw_cat   = s.get("category_id")
            s["_cat"] = str(raw_cat).strip() if raw_cat is not None else "0"
            cat_counts[s["_cat"]] = cat_counts.get(s["_cat"], 0) + 1

        SERIES_LIST = [s for s in all_s if isinstance(s, dict)]

        for cat in SERIES_CATEGORIES:
            cid = str(cat["id"]).strip()
            if cid == "all":
                cat["count"] = len(SERIES_LIST)
            else:
                cat["count"] = cat_counts.get(cid, 0)

        print("[UnionStream] xtream series: %d series, %d categories" % (
            len(SERIES_LIST), len(SERIES_CATEGORIES)-1))
        return True
    except Exception as e:
        print("[UnionStream] xtream series ERREUR:", e)
        return False

def series_for_cat(cat_id):
    """Filtre SERIES_LIST par categorie (normalisation str, identique a channels_for_cat)."""
    if cat_id == "all":
        return list(SERIES_LIST)
    cid = str(cat_id).strip()
    return [s for s in SERIES_LIST if str(s.get("_cat", s.get("category_id", ""))).strip() == cid]

def load_series_data(on_done=None):
    """Charge cats + series depuis le serveur actif en thread."""
    srv = _active_server()
    if not srv:
        if on_done:
            on_done(False, "Aucun serveur actif.")
        return

    def _worker():
        t   = srv.get("type", "")
        url = srv.get("url", "").strip()
        ok  = False
        msg = ""
        try:
            if t == "STALKER":
                mac   = srv.get("mac", "00:1A:79:00:00:00")
                token = _stalker_token(url, mac)
                if token:
                    ok  = _stalker_load_series_cats(url, mac, token)
                    msg = ("%d categories series" % (len(SERIES_CATEGORIES)-1)) if ok else "Erreur cats Series Stalker"
                else:
                    msg = "Echec auth Stalker"
            elif t == "Xtream":
                usr = srv.get("user", "").strip()
                pwd = srv.get("pass", "").strip()
                ok  = _xtream_load_series(url, usr, pwd)
                msg = ("%d series, %d categories" % (len(SERIES_LIST), len(SERIES_CATEGORIES)-1)) if ok else "Erreur Series Xtream"
            else:
                msg = "Series non disponibles pour M3U"
        except Exception as e:
            msg = str(e)
        if on_done:
            on_done(ok, msg)

    threading.Thread(target=_worker, daemon=True).start()

def load_server_data(on_done=None, cat_id="all"):
    """
    Charge bouquets + chaines depuis le serveur actif en thread.
    on_done(ok, message) est appele dans le thread - utiliser eCallInMainThread si besoin.
    """
    srv = _active_server()
    if not srv:
        if on_done:
            on_done(False, "Aucun serveur actif.")
        return

    def _worker():
        t   = srv.get("type", "STALKER")
        url = srv.get("url", "").strip()
        ok  = False
        msg = ""
        try:
            if t == "STALKER":
                mac   = srv.get("mac", "00:1A:79:00:00:00")
                token = _stalker_token(url, mac)
                if token:
                    _stalker_load_categories(url, mac, token)
                    ok  = _stalker_load_channels(url, mac, token, cat_id)
                    msg = ("%d bouquets, %d chaines" % (len(CATEGORIES)-1, len(CHANNELS))) if ok else "Erreur chaines Stalker"
                else:
                    msg = "Echec auth Stalker (token vide)"
            elif t == "Xtream":
                usr = srv.get("user", "").strip()
                pwd = srv.get("pass", "").strip()
                _xtream_load_categories(url, usr, pwd)
                ok  = _xtream_load_channels(url, usr, pwd)  # toujours all
                msg = ("%d bouquets, %d chaines" % (len(CATEGORIES)-1, len(CHANNELS))) if ok else "Erreur chaines Xtream"
            elif t == "M3U":
                ok  = _m3u_load(srv.get("playlist", url))
                msg = ("%d bouquets, %d chaines" % (len(CATEGORIES)-1, len(CHANNELS))) if ok else "Erreur M3U"
            else:
                msg = "Type inconnu : %s" % t
        except Exception as e:
            msg = "Erreur : %s" % e
            print("[UnionStream] load_server_data:", e)
        if on_done:
            on_done(ok, msg)

    threading.Thread(target=_worker, daemon=True).start()

def load_server_cats_only(on_done=None):
    """Charge uniquement les bouquets/categories (sans les chaines)."""
    srv = _active_server()
    if not srv:
        if on_done:
            on_done(False, "Aucun serveur actif.")
        return

    def _worker():
        t   = srv.get("type", "STALKER")
        url = srv.get("url", "").strip()
        ok  = False
        msg = ""
        try:
            if t == "STALKER":
                mac   = srv.get("mac", "00:1A:79:00:00:00")
                token = _stalker_token(url, mac)
                ok    = _stalker_load_categories(url, mac, token) if token else False
                msg   = ("%d bouquets" % (len(CATEGORIES)-1)) if ok else "Echec auth Stalker"
            elif t == "Xtream":
                usr = srv.get("user", "").strip()
                pwd = srv.get("pass", "").strip()
                ok1 = _xtream_load_categories(url, usr, pwd)
                ok2 = _xtream_load_channels(url, usr, pwd)  # charger les chaines aussi
                ok  = ok1 and ok2
                msg = ("%d bouquets, %d chaines" % (len(CATEGORIES)-1, len(CHANNELS))) if ok else "Erreur Xtream"
            elif t == "M3U":
                ok  = _m3u_load(srv.get("playlist", url))
                msg = ("%d bouquets" % (len(CATEGORIES)-1)) if ok else "Erreur M3U"
        except Exception as e:
            msg = str(e)
        if on_done:
            on_done(ok, msg)

    threading.Thread(target=_worker, daemon=True).start()


def http_get(url, timeout=10):
    try:
        req = Request(url, headers={"User-Agent":"UnionStream/3.2.4"})
        resp = urlopen(req, timeout=timeout)
        return resp.read()
    except (URLError, HTTPError, OSError) as e:
        print("[UnionStream] http_get:", e)
        return None

class UnionStreamService:
    _timer = None

    @classmethod
    def start(cls):
        _init_config()
        c = cfg()
        if c and c.epg_enabled.value:
            cls._timer = eTimer()
            cls._timer.callback.append(cls._on_timer)
            cls._timer.start(6 * 3600 * 1000, False)
            print("[UnionStream] EPG service start")

    @classmethod
    def stop(cls):
        if cls._timer:
            cls._timer.stop()
            cls._timer = None

    @classmethod
    def _on_timer(cls):
        threading.Thread(target=cls._fetch, daemon=True).start()

    @staticmethod
    def _fetch():
        c = cfg()
        if not c:
            return
        data = http_get(c.epg_url.value, timeout=20)
        if data:
            try:
                with open(EPG_FILE, "wb") as f:
                    f.write(data)
            except Exception as e:
                print("[UnionStream] EPG write:", e)


# ===================================================================
#  Add Player plein écran avec OSD (simplifié)
# ===================================================================
class UnionStreamPlayer(Screen):
    def __init__(self, session, channels, current_index, current_cat, player_stype=4097):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream Player" flags="wfNoBorder" backgroundColor="transparent">
                <!-- Overlay OSD transparent -->
                <widget name="osd_bg" position="0,850" size="1920,230" backgroundColor="#aa000000" zPosition="1" />
                <widget name="channel_info" position="40,970" size="700,70" font="Regular;50" foregroundColor="#edf5f4" backgroundColor="#0e75e3" zPosition="2" />
                <widget name="channel_list" position="1400,150" size="400,800" backgroundColor="#0e75e3" font="Regular;24" foregroundColor="#edf5f4" itemHeight="36" zPosition="2" />
            </screen>
        """
        self.setTitle("Union Stream Player")

        self.session = session
        self.channels = channels
        self.current_index = current_index
        self.current_cat = current_cat
        self.player_stype = player_stype
        self.osd_visible = True

        # Timer pour cacher l'OSD
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_osd)

        # Widgets
        self["osd_bg"] = Label("")
        self["channel_info"] = Label("")
        self["channel_list"] = MenuList([])

        # Démarrer la lecture
        self.play_current()

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "ChannelSelectBaseActions"],
            {
                "ok": self.toggle_osd,
                "up": self.channel_up,
                "down": self.channel_down,
                "left": self.prev_channel,
                "right": self.next_channel,
                "channelUp": self.next_channel,
                "channelDown": self.prev_channel,
                "red": self.stop_and_exit,
                "cancel": self.stop_and_exit,
            }, -1)

        self.show_osd()
        self.start_hide_timer()

    def play_current(self):
        ch = self.channels[self.current_index]
        ref = eServiceReference(self.player_stype, 0, ch["url"])
        ref.setName(ch["name"])
        self.session.nav.playService(ref)
        self.update_osd_info()

    def update_osd_info(self):
        ch = self.channels[self.current_index]
        self["channel_info"].setText(f"{ch['num']}. {ch['name']}")
        self.build_channel_list()

    def build_channel_list(self):
        entries = []
        for i, ch in enumerate(self.channels):
            marker = "> " if i == self.current_index else "  "
            entries.append((f"{marker}{ch['num']}. {ch['name']}", ch))
        self["channel_list"].setList(entries)

    def toggle_osd(self):
        if self.osd_visible:
            self.hide_osd()
        else:
            self.show_osd()

    def show_osd(self):
        self.osd_visible = True
        self["osd_bg"].show()
        self["channel_info"].show()
        self["channel_list"].show()
        self.start_hide_timer()

    def hide_osd(self):
        self.osd_visible = False
        self["osd_bg"].hide()
        self["channel_info"].hide()
        self["channel_list"].hide()
        self.hide_timer.stop()

    def start_hide_timer(self):
        self.hide_timer.stop()
        self.hide_timer.start(8000, True)

    def channel_up(self):
        if self.osd_visible:
            if self.current_index > 0:
                self.current_index -= 1
                self.play_current()
                self.start_hide_timer()
        else:
            self.prev_channel()

    def channel_down(self):
        if self.osd_visible:
            if self.current_index < len(self.channels)-1:
                self.current_index += 1
                self.play_current()
                self.start_hide_timer()
        else:
            self.next_channel()

    def next_channel(self):
        self.current_index = (self.current_index + 1) % len(self.channels)
        self.play_current()
        if self.osd_visible:
            self.start_hide_timer()

    def prev_channel(self):
        self.current_index = (self.current_index - 1) % len(self.channels)
        self.play_current()
        if self.osd_visible:
            self.start_hide_timer()

    def stop_and_exit(self):
        self.session.nav.stopService()
        self.hide_timer.stop()
        self.close()


# ===================================================================
#  Écran principal
# ===================================================================
class UnionStreamMain(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream IPTV">

                <!-- ===== BARRE DE TITRE ===== -->
                <widget name="title" position="center,20" size="500,50" font="Regular;50" foregroundColor="#ffffff"  text="Union Stream IPTV" />
                <widget name="subtitle" position="center,90" size="500,40" font="Regular;30" foregroundColor="#cccccc"  text="by Said M.S" />

                <!-- ===== MENU GAUCHE ===== -->
                <widget name="lbl_menu"    position="10,200"     size="250,60"    font="Regular;34" foregroundColor="#4da6ff" backgroundColor="#111122" text="  Menu" />
                <widget name="mn_livetv"   position="10,290"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#1565c0" text="  Live TV" />
                <widget name="mn_vod"      position="10,380"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  VOD" />
                <widget name="mn_series"   position="10,470"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Series" />
                <widget name="mn_servers"  position="10,560"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Servers" />
                <widget name="mn_settings" position="10,650"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Setting" />

                <!-- ===== ZONE PRINCIPALE ===== -->
                <widget name="lbl_section" position="300,200"   size="260,50"    font="Regular;30" foregroundColor="#ffffff" backgroundColor="#d4c00d" text="  Live TV" halign="center" />
                <widget name="btn_play"    position="1680,150"   size="180,50"    font="Regular;24" foregroundColor="#ffffff" backgroundColor="#2e7d32" text="Read" halign="center" />
                <widget name="btn_reload"  position="1680,100"   size="180,50"    font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1565c0" text="Reload" halign="center" />
                <widget name="btn_quit"    position="1680,200"   size="180,50"    font="Regular;24" foregroundColor="#ffffff" backgroundColor="#cc0000" text="Exit" halign="center" />

                <!-- En-tetes colonnes -->
                <widget name="hdr_cats"    position="300,290"  size="360,36"    font="Regular;24" foregroundColor="#4da6ff" backgroundColor="#111133" text="  Categories" />
                <widget name="hdr_elems"   position="670,290"  size="870,36"    font="Regular;24" foregroundColor="#ffffff" backgroundColor="#111133" text="  Elements" />
                <widget name="lbl_page"    position="1560,290" size="330,36"    font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111133" text="Page 1/1 | 0 total" />

                <!-- Listes -->
                <widget name="cat_list"    position="300,330"  size="360,600"   font="Regular;24" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />
                <widget name="ch_list"     position="670,330"  size="1220,600"  font="Regular;24" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />

                <!-- Barre de statut -->
                <widget name="lbl_status"  position="260,950"  size="1630,40"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111122" text="  0 load elements" />

                <!-- Barre inferieure -->
                <widget name="lbl_active"  position="0,1030"   size="800,50"    font="Regular;24" foregroundColor="#00cc00" backgroundColor="#0d0d1a" text="  Serveur actif : ---" />
                <widget name="lbl_player"  position="1500,1030" size="400,50"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="  Player : IPTV (4097)" />
                <!-- Horloge coin superieur droit du menu -->
                <widget name="clock"       position="1650,30"   size="250,60"    font="Regular;28" foregroundColor="#37ff00"  halign="center" text="00:00:00" />

            </screen>
        """
        _init_config()
        self.setTitle("Union Stream IPTV")

        self.favorites    = load_favorites()
        self.current_cat  = "all"
        self.playing_ch   = None

        # Focus : "menu" | "cats" | "chans"
        self._MENU_ITEMS = ["livetv","vod","series","servers","settings"]
        self._menu_idx   = 0
        self._focus      = "cats"

        # ── Barre titre ──
        self["hdr_bg"]      = Label("")

        self["title"] = Label("Union Stream IPTV")
        self["subtitle"] = Label("by Said M.S")

        # ── Menu gauche ──
        self["lbl_menu"]    = Label("  Menu")
        self["mn_livetv"]   = Label("  Live TV")
        self["mn_vod"]      = Label("  VOD")
        self["mn_series"]   = Label("  Series")
        self["mn_servers"]  = Label("  Servers")
        self["mn_settings"] = Label("  Setting")

        # ── Zone principale ──
        self["lbl_section"] = Label("  Live TV")
        self["btn_play"]    = Label(" Read")
        self["btn_reload"]  = Label(" Reload")
        self["btn_quit"]    = Label(" Exit")
        self["hdr_cats"]    = Label("  Categories")
        self["hdr_elems"]   = Label("  Elements")
        self["lbl_page"]    = Label("Page 1/1 | 0 total")
        self["cat_list"]    = MenuList(self._build_cats())
        self["ch_list"]     = MenuList([])
        self["lbl_status"]  = Label("  0 load elements")

        # ── Barre inferieure ──
        self["lbl_active"]  = Label("  Serveur actif : ---")
        self["lbl_player"]  = Label("  Player : IPTV (4097)")
        self["clock"]       = Label("")

        # ── Widgets NPV invisibles ──
        self["np_channel"]  = Label("")
        self["np_program"]  = Label("")
        self["np_time"]     = Label("")
        self["np_progress"] = ProgressBar()

        # Initialisation
        self._refresh_ch()
        self._update_menu_highlight()
        self._update_active_server()

        # Chargement initial du serveur actif
        self._initial_load()

        # Horloge (timer keep-alive)
        self._clk = eTimer()
        self._clk.callback.append(self._tick)
        self._clk.start(1000, False)
        self._tick()  # affichage immediat

        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions","InfoActions","ChannelSelectBaseActions"],
            {
                "ok":          self.on_ok,
                "cancel":      self.on_cancel,
                "up":          self.on_up,
                "down":        self.on_down,
                "left":        self.on_left,
                "right":       self.on_right,
                "green":       self.do_play,
                "red":         self._stop,
                "yellow":      self.on_yellow,
                "blue":        self.do_reload,
                "info":        self.on_info,
                "nextBouquet": self.next_ch,
                "prevBouquet": self.prev_ch,
            }, -1
        )

    # ── Horloge ───────────────────────────────────────────────────────────
    def _tick(self):
        self["clock"].setText(datetime.now().strftime("%H:%M:%S"))

    # ── Serveur actif ─────────────────────────────────────────────────────
    def _update_active_server(self):
        active = next((s for s in SERVERS_DB if s["active"]), None)
        if active:
            self["lbl_active"].setText("  Serveur actif : %s (%s)" % (active["name"], active["type"]))

    # ── Chargement initial au demarrage ───────────────────────────────────
    def _initial_load(self):
        """Charge bouquets + chaines du serveur actif au demarrage."""
        srv = _active_server()
        if not srv:
            self["lbl_status"].setText("  Aucun serveur actif - allez dans Servers")
            return
        self["lbl_status"].setText("  Chargement : %s..." % srv.get("name",""))
        self["cat_list"].setList([("  Chargement...", {"id":"all","name":"All","count":0})])

        def on_done(ok, msg):
            self._reload_cats_ui()
            self._refresh_ch()
            if ok:
                self["lbl_status"].setText("  %s" % msg)

        t = srv.get("type", "")
        if t == "Xtream":
            # Xtream : charger cats ET toutes les chaines en une seule passe
            load_server_data(on_done=on_done, cat_id="all")
        else:
            load_server_cats_only(on_done=on_done)

    # ── Highlight menu gauche ─────────────────────────────────────────────
    _MN_WIDGETS = {
        "livetv":   "mn_livetv",
        "vod":      "mn_vod",
        "series":   "mn_series",
        "servers":  "mn_servers",
        "settings": "mn_settings",
    }
    _MN_LABELS = {
        "livetv":   "  Live TV",
        "vod":      "  VOD",
        "series":   "  Series",
        "servers":  "  Servers",
        "settings": "  Setting",
    }

    def _update_menu_highlight(self):
        active = self._MENU_ITEMS[self._menu_idx]
        for key, wname in self._MN_WIDGETS.items():
            if key == active and self._focus == "menu":
                self[wname].setText("> " + self._MN_LABELS[key].strip())
            else:
                self[wname].setText(self._MN_LABELS[key])

    # ── Construction listes ───────────────────────────────────────────────
    def _build_cats(self):
        """Construit la liste des categories depuis CATEGORIES global."""
        res = []
        for c in CATEGORIES:
            lbl = c["name"]
            cnt = c.get("count", 0)
            if cnt:
                lbl += " (%d)" % cnt
            res.append((lbl, c))
        return res

    def _reload_cats_ui(self):
        """Rafraichit la liste des categories a l'ecran."""
        entries = self._build_cats()
        self["cat_list"].setList(entries)
        total_cats = len(CATEGORIES) - 1
        self["lbl_status"].setText("  %d bouquets charges" % total_cats)

    def _refresh_ch(self):
        """Affiche les chaines du bouquet courant (depuis CHANNELS global)."""
        chs = channels_for_cat(self.current_cat)
        entries = []
        for i, ch in enumerate(chs):
            mk = " *" if ch["num"] in self.favorites else ""
            pl = " >" if (self.playing_ch and ch["num"] == self.playing_ch.get("num")) else ""
            entries.append(("%d. %s%s%s" % (i+1, ch["name"], mk, pl), ch))
        self["ch_list"].setList(entries)
        total = len(chs)
        self["lbl_status"].setText("  %d load elements" % total)
        self["lbl_page"].setText("Page 1/1 | %d total" % total)

    def _load_channels_for_cat(self, cat_id):
        """Affiche les chaines du bouquet cat_id."""
        srv = _active_server()
        if not srv:
            self["lbl_status"].setText("  Aucun serveur actif")
            self["ch_list"].setList([])
            return

        t = srv.get("type", "")

        # Xtream et M3U : toutes les chaines sont deja en cache → filtre local instantane
        if t in ("Xtream", "M3U"):
            chs = channels_for_cat(cat_id)
            if chs or not CHANNELS:
                self._refresh_ch()
                self["lbl_status"].setText("  %d chaines" % len(chs))
                return
            # Cache vide (premier demarrage sans load_server_data) → Reload
            t = "Xtream"  # laisser tomber dans le bloc de rechargement ci-dessous

        # STALKER (ou Xtream sans cache) : requete reseau dans un thread
        self["lbl_status"].setText("  Chargement en cours...")
        self["ch_list"].setList([("  Chargement...", {})])

        def on_done(ok, msg):
            self._refresh_ch()
            if not ok:
                self.session.open(MessageBox, "Erreur : %s" % msg,
                                  MessageBox.TYPE_ERROR, timeout=4)

        url = srv.get("url", "")

        def _worker():
            ok  = False
            msg = ""
            try:
                if srv.get("type") == "STALKER":
                    mac   = srv.get("mac", "00:1A:79:00:00:00")
                    token = _stalker_token(url, mac)
                    if token:
                        ok  = _stalker_load_channels(url, mac, token, cat_id)
                        msg = "%d chaines" % len(channels_for_cat(cat_id)) if ok else "Erreur Stalker"
                    else:
                        msg = "Echec auth Stalker"
                else:  # Xtream sans cache
                    usr = srv.get("user", "").strip()
                    pwd = srv.get("pass", "").strip()
                    ok  = _xtream_load_channels(url, usr, pwd)
                    msg = "%d chaines" % len(channels_for_cat(cat_id)) if ok else "Erreur Xtream"
            except Exception as e:
                msg = str(e)
            on_done(ok, msg)

        import threading as _th
        _th.Thread(target=_worker, daemon=True).start()

    # ── Navigation ────────────────────────────────────────────────────────
    def on_up(self):
        if self._focus == "menu":
            self._menu_idx = (self._menu_idx - 1) % len(self._MENU_ITEMS)
            self._update_menu_highlight()
        elif self._focus == "cats":
            self["cat_list"].up()
            s = self["cat_list"].getCurrent()
            if s and s[1].get("id"):
                self.current_cat = s[1]["id"]
                self._refresh_ch()
        else:
            self["ch_list"].up()

    def on_down(self):
        if self._focus == "menu":
            self._menu_idx = (self._menu_idx + 1) % len(self._MENU_ITEMS)
            self._update_menu_highlight()
        elif self._focus == "cats":
            self["cat_list"].down()
            s = self["cat_list"].getCurrent()
            if s and s[1].get("id"):
                self.current_cat = s[1]["id"]
                self._refresh_ch()
        else:
            self["ch_list"].down()

    def on_left(self):
        if self._focus == "chans":
            self._focus = "cats"
        elif self._focus == "cats":
            self._focus = "menu"
        self._update_menu_highlight()

    def on_right(self):
        if self._focus == "menu":
            self._focus = "cats"
        elif self._focus == "cats":
            self._focus = "chans"
        self._update_menu_highlight()

    def on_ok(self):
        if self._focus == "menu":
            self._activate_menu()
        elif self._focus == "cats":
            s = self["cat_list"].getCurrent()
            if s and s[1].get("id"):
                self.current_cat = s[1]["id"]
                self._focus = "chans"
                self._load_channels_for_cat(self.current_cat)
        else:
            s = self["ch_list"].getCurrent()
            if s:
                self._play(s[1])

    def _activate_menu(self):
        item = self._MENU_ITEMS[self._menu_idx]
        if item == "livetv":
            self._focus = "cats"
            self._update_menu_highlight()
        elif item == "vod":
            self.session.open(UnionStreamVOD)
        elif item == "series":
            self.session.open(UnionStreamSeries)
        elif item == "servers":
            self.session.open(UnionStreamServers)
        elif item == "settings":
            self.session.open(UnionStreamSettings)

    # ── Helpers Players ──────────────────────────────────────────────────
    _PLAYER_STYPES = {
        "DVB":        1,
        "IPTV":       4097,
        "GStreamer":  5001,
        "ExtePlayer": 5002,
    }
    _PLAYER_LABELS = {
        "DVB":        "DVB (1)",
        "IPTV":       "IPTV (4097)",
        "GStreamer":  "GStreamer (5001)",
        "ExtePlayer": "ExtePlayer (5002)",
    }

    def _player_stype(self, c):
        key = c.player.value if c else "IPTV"
        return self._PLAYER_STYPES.get(key, 4097)

    def _player_label(self, c):
        key = c.player.value if c else "IPTV"
        return self._PLAYER_LABELS.get(key, "IPTV (4097)")

    # ── Lecture ───────────────────────────────────────────────────────────
    def do_play(self):
        s = self["ch_list"].getCurrent()
        if s:
            self._play(s[1])

    def _play(self, ch):
        # Trouver l'index de la chaîne dans la liste courante
        chs = channels_for_cat(self.current_cat)
        index = next((i for i, c in enumerate(chs) if c["num"] == ch["num"]), 0)
        c = cfg()
        stype = self._player_stype(c)
        # Cacher l'écran principal pendant la lecture
        self.hide()
        self.session.openWithCallback(self.player_closed, UnionStreamPlayer, chs, index, self.current_cat, stype)

    def player_closed(self, *args):
        # Réafficher l'écran principal
        self.show()
        self._refresh_ch()
        self._update_active_server()

    def do_reload(self):
        """Recharge les bouquets ET les chaines depuis le serveur actif."""
        self["lbl_status"].setText("  Chargement du serveur...")
        self["cat_list"].setList([("  Chargement...", {"id":"all","name":"All","count":0})])
        self["ch_list"].setList([])

        def on_done(ok, msg):
            self._reload_cats_ui()
            self._refresh_ch()
            self.session.open(MessageBox,
                msg if ok else ("Erreur : " + msg),
                MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
                timeout=3)

        load_server_data(on_done=on_done, cat_id=self.current_cat)

    def on_yellow(self):
        s = self["ch_list"].getCurrent()
        if not s:
            return
        num = s[1]["num"]
        if num in self.favorites:
            self.favorites.discard(num)
            msg = "Retire des favoris"
        else:
            self.favorites.add(num)
            msg = "Ajoute aux favoris"
        save_favorites(self.favorites)
        self._refresh_ch()
        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=2)

    def on_info(self):
        s = self["ch_list"].getCurrent()
        if not s:
            return
        ch = s[1]
        self.session.open(MessageBox,
            "Chaine   : %s\nNumero   : %d\nProgramme: %s\nHoraire  : %s --> %s\nURL      : %s" % (
                ch["name"], ch["num"], ch.get("prog","---"),
                ch.get("t1","---"), ch.get("t2","---"), ch["url"]),
            MessageBox.TYPE_INFO)

    def next_ch(self):
        chs = channels_for_cat(self.current_cat)
        if not chs:
            return
        idx = next((i for i,c in enumerate(chs) if self.playing_ch and c["num"] == self.playing_ch.get("num")), -1)
        self._play(chs[(idx+1) % len(chs)])

    def prev_ch(self):
        chs = channels_for_cat(self.current_cat)
        if not chs:
            return
        idx = next((i for i,c in enumerate(chs) if self.playing_ch and c["num"] == self.playing_ch.get("num")), 0)
        self._play(chs[(idx-1) % len(chs)])

    def _stop(self):
        self.session.nav.stopService()
        self.playing_ch = None
        self["np_channel"].setText("")
        self["np_program"].setText("")
        self["np_time"].setText("")
        self["np_progress"].setValue(0)
        self._refresh_ch()

    def open_settings(self):
        self.session.open(UnionStreamSettings)

    def on_cancel(self):
        self._stop()
        self._clk.stop()
        self.close()



# ===================================================================
#  Ecran VOD
# ===================================================================
class UnionStreamVOD(Screen):
    """
    Ecran VOD complet.
    CORRIGE : video en arriere-plan -> ouverture via openWithCallback
    vers UnionStreamPlayer (wfNoBorder), identique a Live TV.
    Thread safety : _eCall (eCallInMainThread) pour tout rappel UI.
    """
    PER_PAGE = 50
    _PLAYER_STYPES = {"DVB": 1, "IPTV": 4097, "GStreamer": 5001, "ExtePlayer": 5002}

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream - VOD">
                <widget name="hdr_bg"      position="0,0"       size="1920,80"  backgroundColor="#0d0d1a" />
                <widget name="lbl_title"   position="30,15"     size="900,52"   font="Regular;38" foregroundColor="#ffffff" backgroundColor="#0d0d1a" text="Union Stream IPTV - VOD" />
                <widget name="lbl_menu"    position="0,130"     size="250,50"   font="Regular;28" foregroundColor="#4da6ff" backgroundColor="#111122" text="  Menu" />
                <widget name="mn_livetv"   position="0,190"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Live TV" />
                <widget name="mn_vod"      position="0,270"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#1565c0" text="  VOD" />
                <widget name="mn_series"   position="0,350"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Series" />
                <widget name="mn_servers"  position="0,430"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Servers" />
                <widget name="mn_settings" position="0,510"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Setting" />
                <widget name="lbl_section" position="260,90"    size="180,50"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#cad40b" text="  VOD" />
                <widget name="btn_play"    position="450,90"    size="130,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#2e7d32" text="Read" halign="center" />
                <widget name="btn_reload"  position="590,90"    size="180,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1565c0" text="Reload" halign="center" />
                <widget name="btn_prev"    position="780,90"    size="180,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#37474f" text="Precedent" halign="center" />
                <widget name="btn_next"    position="970,90"    size="160,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#37474f" text="Suivant" halign="center" />
                <widget name="hdr_cats"    position="260,150"   size="340,36"   font="Regular;22" foregroundColor="#4da6ff" backgroundColor="#111133" text="  Categories" />
                <widget name="hdr_elems"   position="610,150"   size="880,36"   font="Regular;22" foregroundColor="#ffffff" backgroundColor="#111133" text="  Films" />
                <widget name="lbl_page"    position="1500,150"  size="400,36"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111133" text="Page 1/1 | 0 total" />
                <widget name="cat_list"    position="260,190"   size="340,760"  backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />
                <widget name="vod_list"    position="610,190"   size="1300,760" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />
                <widget name="lbl_status"  position="0,965"     size="1920,40"  font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111122" text="  Chargement..." />
                <widget name="lbl_active"  position="0,1010"    size="960,50"   font="Regular;22" foregroundColor="#00cc00" backgroundColor="#0d0d1a" text="  Serveur : ---" />
                <widget name="lbl_player"  position="1500,1010" size="420,50"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="  Player : IPTV" />
            </screen>
        """
        self.setTitle("Union Stream - VOD")
        self._current_cat  = "all"
        self._current_page = 1
        self._total_pages  = 1
        self._focus        = "cats"

        self["hdr_bg"]      = Label("")
        self["lbl_title"]   = Label("Union Stream IPTV - VOD")
        self["lbl_menu"]    = Label("  Menu")
        self["mn_livetv"]   = Label("  Live TV")
        self["mn_vod"]      = Label("  VOD")
        self["mn_series"]   = Label("  Series")
        self["mn_servers"]  = Label("  Servers")
        self["mn_settings"] = Label("  Setting")
        self["lbl_section"] = Label("  VOD")
        self["btn_play"]    = Label("Read")
        self["btn_reload"]  = Label("Reload")
        self["btn_prev"]    = Label("Precedent")
        self["btn_next"]    = Label("Suivant")
        self["hdr_cats"]    = Label("  Categories")
        self["hdr_elems"]   = Label("  Films")
        self["lbl_page"]    = Label("Page 1/1 | 0 total")
        self["cat_list"]    = MenuList([])
        self["vod_list"]    = MenuList([])
        self["lbl_status"]  = Label("  Chargement...")
        self["lbl_active"]  = Label("  Serveur : ---")
        self["lbl_player"]  = Label("  Player : IPTV")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "ChannelSelectBaseActions"],
            {
                "ok":          self.on_ok,
                "cancel":      self.close,
                "up":          self.on_up,
                "down":        self.on_down,
                "left":        self.on_left,
                "right":       self.on_right,
                "green":       self.do_play,
                "blue":        self.do_reload,
                "nextBouquet": self.do_next_page,
                "prevBouquet": self.do_prev_page,
            }, -1)

        self._update_status_bar()
        self._initial_load()

    def _update_status_bar(self):
        srv = _active_server()
        if srv:
            self["lbl_active"].setText("  Serveur : %s (%s)" % (srv.get("name",""), srv.get("type","")))
        c   = cfg()
        key = c.player.value if c else "IPTV"
        self["lbl_player"].setText("  Player : %s" % key)

    def _initial_load(self):
        srv = _active_server()
        if not srv:
            self["lbl_status"].setText("  Aucun serveur actif")
            return
        self["lbl_status"].setText("  Chargement VOD depuis %s..." % srv.get("name",""))
        self["cat_list"].setList([("  Chargement...", {"id":"all","name":"Toutes","count":0})])
        def on_done(ok, msg):
            _eCall(self._on_load_done, ok, msg)
        load_vod_data(on_done=on_done)

    def _on_load_done(self, ok, msg):
        self._rebuild_cats_ui()
        self._refresh_vod()
        self["lbl_status"].setText("  %s" % msg if ok else "  Erreur : %s" % msg)

    def _rebuild_cats_ui(self):
        entries = []
        for c in VOD_CATEGORIES:
            lbl = c["name"]
            cnt = c.get("count", 0)
            if cnt:
                lbl += " (%d)" % cnt
            entries.append((lbl, c))
        self["cat_list"].setList(entries)

    def _refresh_vod(self):
        srv = _active_server()
        t   = srv.get("type","") if srv else ""
        items       = list(VOD_LIST) if t == "STALKER" else vod_for_cat(self._current_cat)
        total       = len(items)
        per_page    = self.PER_PAGE
        total_pages = max(1, (total + per_page - 1) // per_page)
        self._total_pages = total_pages
        start      = (self._current_page - 1) * per_page
        page_items = items[start: start + per_page]
        entries = []
        for i, v in enumerate(page_items):
            name = v.get("name", v.get("title","Film"))
            year = v.get("year","")
            lbl  = "%d. %s" % (start + i + 1, name)
            if year: lbl += " (%s)" % year
            entries.append((lbl, v))
        self["vod_list"].setList(entries)
        self["lbl_page"].setText("Page %d/%d | %d total" % (self._current_page, total_pages, total))
        self["lbl_status"].setText("  %d films charges" % total)

    def on_up(self):
        if self._focus == "cats":
            self["cat_list"].up(); self._on_cat_move()
        else:
            self["vod_list"].up()

    def on_down(self):
        if self._focus == "cats":
            self["cat_list"].down(); self._on_cat_move()
        else:
            self["vod_list"].down()

    def on_left(self):
        if self._focus == "items": self._focus = "cats"

    def on_right(self):
        if self._focus == "cats": self._focus = "items"

    def on_ok(self):
        if self._focus == "cats": self._on_cat_select()
        else: self.do_play()

    def _on_cat_move(self):
        s = self["cat_list"].getCurrent()
        if s and isinstance(s[1], dict):
            self._current_cat  = s[1].get("id","all")
            self._current_page = 1
            self._refresh_vod()

    def _on_cat_select(self):
        s = self["cat_list"].getCurrent()
        if not s: return
        self._current_cat  = s[1].get("id","all") if isinstance(s[1], dict) else "all"
        self._current_page = 1
        self._focus        = "items"
        srv = _active_server()
        if srv and srv.get("type") == "STALKER": self._stalker_load_page()
        else: self._refresh_vod()

    def _stalker_load_page(self):
        srv = _active_server()
        if not srv: return
        url = srv.get("url",""); mac = srv.get("mac","00:1A:79:00:00:00")
        cat = self._current_cat; pg  = self._current_page
        self["lbl_status"].setText("  Chargement page %d..." % pg)
        def _worker():
            token = _stalker_token(url, mac)
            if not token:
                _eCall(self["lbl_status"].setText, "  Erreur auth Stalker"); return
            ok, total, max_pg = _stalker_load_vod_page(url, mac, token, cat, pg)
            self._total_pages = max_pg
            _eCall(self._refresh_vod)
        threading.Thread(target=_worker, daemon=True).start()

    def do_next_page(self):
        if self._current_page < self._total_pages:
            self._current_page += 1
            srv = _active_server()
            if srv and srv.get("type") == "STALKER": self._stalker_load_page()
            else: self._refresh_vod()

    def do_prev_page(self):
        if self._current_page > 1:
            self._current_page -= 1
            srv = _active_server()
            if srv and srv.get("type") == "STALKER": self._stalker_load_page()
            else: self._refresh_vod()

    def do_play(self):
        s = self["vod_list"].getCurrent()
        if not s or not isinstance(s[1], dict): return
        movie = s[1]
        srv   = _active_server()
        if not srv: return
        if srv.get("type") == "STALKER":
            self["lbl_status"].setText("  Connexion au serveur...")
            threading.Thread(target=lambda: self._stalker_resolve_play(movie, srv), daemon=True).start()
        else:
            url = movie.get("_url","")
            if not url:
                base = srv.get("url","").rstrip("/")
                usr  = srv.get("user",""); pwd = srv.get("pass","")
                sid  = movie.get("stream_id", movie.get("video_id",""))
                ext  = (movie.get("container_extension") or "mp4").strip().lstrip(".")
                url  = "%s/movie/%s/%s/%s.%s" % (base, usr, pwd, sid, ext)
            self._open_player(url, movie.get("name", movie.get("title","Film")))

    def _stalker_resolve_play(self, movie, srv):
        import urllib.parse as _up
        url_final = None
        try:
            portal = srv.get("url",""); mac = srv.get("mac","00:1A:79:00:00:00")
            token  = _stalker_token(portal, mac); cmd = movie.get("cmd","")
            req_url = portal.rstrip("/") + "/server/load.php?" + _up.urlencode({
                "type":"vod","action":"create_link","cmd":cmd,"series":"",
                "forced_storage":"undefined","disable_ad":"0","download":"0","JsHttpRequest":"1-xml"})
            req  = Request(req_url, headers={
                "User-Agent":"Mozilla/5.0",
                "Cookie":"mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
                "Authorization":"Bearer %s" % token})
            data = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
            link = data.get("js",{}).get("cmd","")
            if link:
                if link.startswith("ffmpeg "): link = link[7:].strip()
                if link.startswith(("http://","https://","rtsp://","rtmp://")): url_final = link
        except Exception as e:
            print("[VOD] stalker resolve:", e)
        if not url_final:
            cmd = movie.get("cmd","")
            if cmd.startswith("ffmpeg "): cmd = cmd[7:].strip()
            if cmd.startswith(("http://","https://")): url_final = cmd
        name = movie.get("name", movie.get("title","Film"))
        if url_final: _eCall(self._open_player, url_final, name)
        else: _eCall(self.session.open, MessageBox, "Impossible de resoudre l URL du film.", MessageBox.TYPE_ERROR, 4)

    def _open_player(self, url, name):
        c = cfg(); key = c.player.value if c else "IPTV"
        stype = self._PLAYER_STYPES.get(key, 4097)
        self.session.openWithCallback(self._player_closed, UnionStreamPlayer,
                                      [{"num":1,"name":name,"url":url}], 0, "vod", stype)

    def _player_closed(self, *args):
        self["lbl_status"].setText("  Lecture terminee.")
        self._update_status_bar()

    def do_reload(self):
        self._current_page = 1; self._initial_load()


# ===================================================================
#  Ecran Series
# ===================================================================
class UnionStreamSeries(Screen):
    """
    Ecran Series complet.
    CORRIGE : episodes ne se lisaient pas -> session.nav/open appele
    depuis thread secondaire (crash silencieux Enigma2).
    Solution : _eCall (eCallInMainThread) pour tout rappel UI/nav.
    Lecture via openWithCallback -> UnionStreamPlayer (wfNoBorder).
    """
    PER_PAGE = 50

    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream - Series">
                <widget name="hdr_bg"      position="0,0"       size="1920,80"  backgroundColor="#0d0d1a" />
                <widget name="lbl_title"   position="30,15"     size="900,52"   font="Regular;38" foregroundColor="#ffffff" backgroundColor="#0d0d1a" text="Union Stream IPTV - Series" />
                <widget name="lbl_menu"    position="0,130"     size="250,50"   font="Regular;28" foregroundColor="#4da6ff" backgroundColor="#111122" text="  Menu" />
                <widget name="mn_livetv"   position="0,190"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Live TV" />
                <widget name="mn_vod"      position="0,270"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  VOD" />
                <widget name="mn_series"   position="0,350"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#0d0d1a" text="  Series" />
                <widget name="mn_servers"  position="0,430"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Servers" />
                <widget name="mn_settings" position="0,510"     size="250,80"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#222226" text="  Setting" />
                <widget name="lbl_section" position="260,90"    size="200,50"   font="Regular;28" foregroundColor="#ffffff" backgroundColor="#d5e30b" text="  Series" />
                <widget name="btn_seasons" position="470,90"    size="200,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#2e7d32" text="see seasons" halign="center" />
                <widget name="btn_reload"  position="680,90"    size="180,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1565c0" text="Reload" halign="center" />
                <widget name="btn_prev"    position="870,90"    size="180,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#37474f" text="Precedent" halign="center" />
                <widget name="btn_next"    position="1060,90"   size="160,50"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#37474f" text="Suivant" halign="center" />
                <widget name="hdr_cats"    position="260,150"   size="340,36"   font="Regular;22" foregroundColor="#4da6ff" backgroundColor="#111133" text="  Categories" />
                <widget name="hdr_elems"   position="610,150"   size="880,36"   font="Regular;22" foregroundColor="#ffffff" backgroundColor="#111133" text="  Series" />
                <widget name="lbl_page"    position="1500,150"  size="400,36"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111133" text="Page 1/1 | 0 total" />
                <widget name="cat_list"    position="260,190"   size="340,760"  backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />
                <widget name="ser_list"    position="610,190"   size="1300,760" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="36" />
                <widget name="lbl_status"  position="0,965"     size="1920,40"  font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111122" text="  Chargement..." />
                <widget name="lbl_active"  position="0,1010"    size="960,50"   font="Regular;22" foregroundColor="#00cc00" backgroundColor="#0d0d1a" text="  Serveur : ---" />
                <widget name="lbl_player"  position="1500,1010" size="420,50"   font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="  Player : IPTV" />
            </screen>
        """
        self.setTitle("Union Stream - Series")
        self._current_cat  = "all"
        self._current_page = 1
        self._total_pages  = 1
        self._focus        = "cats"

        self["hdr_bg"]      = Label("")
        self["lbl_title"]   = Label("Union Stream IPTV - Series")
        self["lbl_menu"]    = Label("  Menu")
        self["mn_livetv"]   = Label("  Live TV")
        self["mn_vod"]      = Label("  VOD")
        self["mn_series"]   = Label("  Series")
        self["mn_servers"]  = Label("  Servers")
        self["mn_settings"] = Label("  Setting")
        self["lbl_section"] = Label("  Series")
        self["btn_seasons"] = Label("see seasons")
        self["btn_reload"]  = Label("Reload")
        self["btn_prev"]    = Label("Precedent")
        self["btn_next"]    = Label("Suivant")
        self["hdr_cats"]    = Label("  Categories")
        self["hdr_elems"]   = Label("  Series")
        self["lbl_page"]    = Label("Page 1/1 | 0 total")
        self["cat_list"]    = MenuList([])
        self["ser_list"]    = MenuList([])
        self["lbl_status"]  = Label("  Chargement...")
        self["lbl_active"]  = Label("  Serveur : ---")
        self["lbl_player"]  = Label("  Player : IPTV")

        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions","ChannelSelectBaseActions"],
            {
                "ok":          self.on_ok,
                "cancel":      self.close,
                "up":          self.on_up,
                "down":        self.on_down,
                "left":        self.on_left,
                "right":       self.on_right,
                "green":       self.do_seasons,
                "blue":        self.do_reload,
                "nextBouquet": self.do_next_page,
                "prevBouquet": self.do_prev_page,
            }, -1)

        self._update_status_bar()
        self._initial_load()

    def _update_status_bar(self):
        srv = _active_server()
        if srv:
            self["lbl_active"].setText("  Serveur : %s (%s)" % (srv.get("name",""), srv.get("type","")))
        c = cfg(); key = c.player.value if c else "IPTV"
        self["lbl_player"].setText("  Player : %s" % key)

    def _initial_load(self):
        srv = _active_server()
        if not srv:
            self["lbl_status"].setText("  Aucun serveur actif"); return
        self["lbl_status"].setText("  Chargement Series depuis %s..." % srv.get("name",""))
        self["cat_list"].setList([("  Chargement...", {"id":"all","name":"Toutes","count":0})])
        def on_done(ok, msg): _eCall(self._on_load_done, ok, msg)
        load_series_data(on_done=on_done)

    def _on_load_done(self, ok, msg):
        self._rebuild_cats_ui(); self._refresh_series()
        self["lbl_status"].setText("  %s" % msg if ok else "  Erreur : %s" % msg)

    def _rebuild_cats_ui(self):
        entries = []
        for c in SERIES_CATEGORIES:
            lbl = c["name"]; cnt = c.get("count",0)
            if cnt: lbl += " (%d)" % cnt
            entries.append((lbl, c))
        self["cat_list"].setList(entries)

    def _refresh_series(self):
        srv = _active_server(); t = srv.get("type","") if srv else ""
        items       = list(SERIES_LIST) if t == "STALKER" else series_for_cat(self._current_cat)
        total       = len(items); per_page = self.PER_PAGE
        total_pages = max(1, (total + per_page - 1) // per_page)
        self._total_pages = total_pages
        start = (self._current_page - 1) * per_page
        page_items = items[start: start + per_page]
        entries = []
        for i, s in enumerate(page_items):
            name = s.get("name", s.get("title","Serie")); year = s.get("year",""); country = s.get("country","")
            lbl  = "%d. %s" % (start + i + 1, name)
            if year: lbl += " (%s)" % year
            if country: lbl += " [%s]" % country
            entries.append((lbl, s))
        self["ser_list"].setList(entries)
        self["lbl_page"].setText("Page %d/%d | %d total" % (self._current_page, total_pages, total))
        self["lbl_status"].setText("  %d series chargees" % total)

    def on_up(self):
        if self._focus == "cats": self["cat_list"].up(); self._on_cat_move()
        else: self["ser_list"].up()

    def on_down(self):
        if self._focus == "cats": self["cat_list"].down(); self._on_cat_move()
        else: self["ser_list"].down()

    def on_left(self):
        if self._focus == "items": self._focus = "cats"

    def on_right(self):
        if self._focus == "cats": self._focus = "items"

    def on_ok(self):
        if self._focus == "cats": self._on_cat_select()
        else: self.do_seasons()

    def _on_cat_move(self):
        s = self["cat_list"].getCurrent()
        if s and isinstance(s[1], dict):
            self._current_cat = s[1].get("id","all"); self._current_page = 1; self._refresh_series()

    def _on_cat_select(self):
        s = self["cat_list"].getCurrent()
        if not s: return
        self._current_cat  = s[1].get("id","all") if isinstance(s[1], dict) else "all"
        self._current_page = 1; self._focus = "items"
        srv = _active_server()
        if srv and srv.get("type") == "STALKER": self._stalker_load_page()
        else: self._refresh_series()

    def _stalker_load_page(self):
        srv = _active_server()
        if not srv: return
        url = srv.get("url",""); mac = srv.get("mac","00:1A:79:00:00:00")
        cat = self._current_cat; pg  = self._current_page
        self["lbl_status"].setText("  Chargement page %d..." % pg)
        def _worker():
            token = _stalker_token(url, mac)
            if not token:
                _eCall(self["lbl_status"].setText, "  Erreur auth Stalker"); return
            ok, total, max_pg = _stalker_load_series_page(url, mac, token, cat, pg)
            self._total_pages = max_pg; _eCall(self._refresh_series)
        threading.Thread(target=_worker, daemon=True).start()

    def do_next_page(self):
        if self._current_page < self._total_pages:
            self._current_page += 1
            srv = _active_server()
            if srv and srv.get("type") == "STALKER": self._stalker_load_page()
            else: self._refresh_series()

    def do_prev_page(self):
        if self._current_page > 1:
            self._current_page -= 1
            srv = _active_server()
            if srv and srv.get("type") == "STALKER": self._stalker_load_page()
            else: self._refresh_series()

    def do_seasons(self):
        s = self["ser_list"].getCurrent()
        if not s or not isinstance(s[1], dict): return
        serie = s[1]; name = serie.get("name", serie.get("title","Serie"))
        srv = _active_server()
        if not srv: return
        t = srv.get("type","")
        if t == "STALKER":
            sid = str(serie.get("id",""))
            if not sid:
                self.session.open(MessageBox, "ID serie manquant.", MessageBox.TYPE_ERROR, 3); return
            self["lbl_status"].setText("  Chargement saisons...")
            threading.Thread(target=lambda: self._stalker_fetch_seasons(sid, name, srv), daemon=True).start()
        elif t == "Xtream":
            sid = str(serie.get("series_id", serie.get("id","")))
            if not sid:
                self.session.open(MessageBox, "ID serie manquant.", MessageBox.TYPE_ERROR, 3); return
            self["lbl_status"].setText("  Chargement infos serie...")
            threading.Thread(target=lambda: self._xtream_fetch_info(sid, name, srv), daemon=True).start()
        else:
            self.session.open(MessageBox, "Series non disponibles pour M3U.", MessageBox.TYPE_INFO, 3)

    def do_reload(self):
        self._current_page = 1; self._initial_load()

    def _stalker_fetch_seasons(self, series_id, series_name, srv):
        try:
            import urllib.parse as _up
            url = srv.get("url",""); mac = srv.get("mac","00:1A:79:00:00:00")
            token = _stalker_token(url, mac)
            req_url = url.rstrip("/") + "/server/load.php?" + _up.urlencode({
                "type":"series","action":"get_seasons","movie_id":str(series_id),"JsHttpRequest":"1-xml"})
            req = Request(req_url, headers={"User-Agent":"Mozilla/5.0",
                "Cookie":"mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
                "Authorization":"Bearer %s" % token})
            data    = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
            seasons = data.get("js",[])
            if isinstance(seasons, dict): seasons = seasons.get("data",[])
            _eCall(self.session.open, _SeasonsScreen, seasons, series_id, series_name, "stalker", srv)
        except Exception as e:
            print("[Series] stalker saisons:", e)
            _eCall(self["lbl_status"].setText, "  Erreur saisons : %s" % str(e)[:60])

    def _xtream_fetch_info(self, series_id, series_name, srv):
        try:
            base = srv.get("url","").rstrip("/"); usr = srv.get("user",""); pwd = srv.get("pass","")
            url = "%s/player_api.php?username=%s&password=%s&action=get_series_info&series_id=%s" % (base, usr, pwd, series_id)
            raw  = urlopen(Request(url, headers={"User-Agent":"Mozilla/5.0 (SmartTV)"}), timeout=20).read()
            data = json.loads(raw.decode("utf-8", errors="replace"))
            seasons_dict = data.get("episodes",{})
            _eCall(self.session.open, _SeasonsScreen, seasons_dict, series_id, series_name, "xtream", srv)
        except Exception as e:
            print("[Series] xtream info:", e)
            _eCall(self["lbl_status"].setText, "  Erreur infos serie : %s" % str(e)[:60])


# ===================================================================
#  Popup Saisons
# ===================================================================
class _SeasonsScreen(Screen):
    def __init__(self, session, seasons_data, series_id, series_name, mode, srv):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="310,160" size="1300,700" title="Saisons">
                <widget name="lbl_title"  position="20,20"   size="1260,54" font="Regular;36" foregroundColor="#ffffff" backgroundColor="#111133" />
                <widget name="lbl_hint"   position="20,84"   size="1260,34" font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#111133" text="  OK = ouvrir  |  Annuler = retour" />
                <widget name="sea_list"   position="20,128"  size="1260,490" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="44" />
                <widget name="lbl_status" position="20,630"  size="1260,40" font="Regular;22" foregroundColor="#aaaaaa" backgroundColor="#111122" text="" />
            </screen>
        """
        self.setTitle("Saisons")
        self._mode = mode; self._series_id = series_id
        self._series_name = series_name; self._srv = srv
        self["lbl_title"]  = Label("  %s" % series_name)
        self["lbl_hint"]   = Label("  OK = ouvrir  |  Annuler = retour")
        self["sea_list"]   = MenuList([])
        self["lbl_status"] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions"],
            {"ok":self.on_ok,"green":self.on_ok,"cancel":self.close,
             "up":lambda: self["sea_list"].up(),"down":lambda: self["sea_list"].down()}, -1)
        self._build(seasons_data)

    def _build(self, data):
        entries = []
        if self._mode == "stalker":
            self._stalker_seasons = data if isinstance(data, list) else []
            for s in self._stalker_seasons:
                if isinstance(s, dict):
                    num = s.get("season_number", s.get("id","?"))
                    name = s.get("name","Saison %s" % num)
                    entries.append(("  Saison %s  -  %s" % (num, name), s))
        else:
            if not isinstance(data, dict): data = {}
            self._xtream_dict = data
            self._xtream_keys = sorted(data.keys(), key=lambda x: int(x) if str(x).isdigit() else 0)
            for k in self._xtream_keys:
                nb = len(data[k])
                entries.append(("  Saison %s  -  %d episode%s" % (k, nb, "s" if nb>1 else ""), k))
        if not entries: self["lbl_status"].setText("  Aucune saison trouvee")
        self["sea_list"].setList(entries)

    def on_ok(self):
        s = self["sea_list"].getCurrent()
        if not s: return
        if self._mode == "stalker":
            season = s[1]; season_num = str(season.get("season_number", season.get("id","1")))
            self["lbl_status"].setText("  Chargement episodes S%s..." % season_num)
            threading.Thread(target=lambda: self._stalker_load_episodes(season_num), daemon=True).start()
        else:
            season_key = s[1]; episodes = self._xtream_dict.get(season_key,[])
            self.session.open(_EpisodesScreen, episodes, self._series_name, season_key, "xtream", self._srv)

    def _stalker_load_episodes(self, season_num):
        try:
            import urllib.parse as _up
            url = self._srv.get("url",""); mac = self._srv.get("mac","00:1A:79:00:00:00")
            token = _stalker_token(url, mac)
            req_url = url.rstrip("/") + "/server/load.php?" + _up.urlencode({
                "type":"series","action":"get_episodes","movie_id":str(self._series_id),
                "season":str(season_num),"JsHttpRequest":"1-xml"})
            req = Request(req_url, headers={"User-Agent":"Mozilla/5.0",
                "Cookie":"mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
                "Authorization":"Bearer %s" % token})
            data     = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
            episodes = data.get("js",[])
            if isinstance(episodes, dict): episodes = episodes.get("data",[])
            _eCall(self.session.open, _EpisodesScreen,
                episodes, self._series_name, season_num, "stalker", self._srv)
        except Exception as e:
            print("[Series] stalker episodes:", e)
            _eCall(self["lbl_status"].setText, "  Erreur episodes : %s" % str(e)[:60])


# ===================================================================
#  Popup Episodes
# ===================================================================
class _EpisodesScreen(Screen):
    """
    CORRIGE lecture episodes.
    Stalker : create_link dans thread -> _eCall -> _open_player (main thread).
    Xtream  : URL directe -> _open_player direct (main thread).
    _open_player : openWithCallback -> UnionStreamPlayer (wfNoBorder) -> video premier plan.
    """
    _PLAYER_STYPES = {"DVB":1,"IPTV":4097,"GStreamer":5001,"ExtePlayer":5002}

    def __init__(self, session, episodes, series_name, season_num, mode, srv):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="230,120" size="1460,800" title="Episodes">
                <widget name="lbl_title"  position="20,20"   size="1420,54" font="Regular;36" foregroundColor="#ffffff" backgroundColor="#111133" />
                <widget name="lbl_hint"   position="20,84"   size="1420,34" font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#111133" text="  OK = Read  |  Annuler = retour" />
                <widget name="ep_list"    position="20,128"  size="1420,570" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="44" />
                <widget name="lbl_status" position="20,710"  size="1420,42" font="Regular;22" foregroundColor="#aaaaaa" backgroundColor="#111122" text="" />
            </screen>
        """
        self.setTitle("Episodes")
        self._episodes = episodes if isinstance(episodes, list) else []
        self._series_name = series_name; self._season_num = season_num
        self._mode = mode; self._srv = srv
        nb = len(self._episodes)
        self["lbl_title"]  = Label("  %s  -  Saison %s  (%d ep.)" % (series_name, season_num, nb))
        self["lbl_hint"]   = Label("  OK = Read  |  Annuler = retour")
        self["ep_list"]    = MenuList([])
        self["lbl_status"] = Label("  Selectionnez un episode")
        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions"],
            {"ok":self.on_ok,"green":self.on_ok,"cancel":self.close,
             "up":lambda: self["ep_list"].up(),"down":lambda: self["ep_list"].down()}, -1)
        self._build()

    def _build(self):
        entries = []
        for ep in self._episodes:
            if not isinstance(ep, dict): continue
            if self._mode == "stalker":
                en = ep.get("series", ep.get("episode_number","?"))
                ename = ep.get("name", ep.get("title","Episode %s" % en))
            else:
                en = ep.get("episode_num", ep.get("id","?"))
                ename = ep.get("title", ep.get("name","Episode %s" % en))
            entries.append(("  S%sE%s  -  %s" % (self._season_num, en, ename), ep))
        if not entries: self["lbl_status"].setText("  Aucun episode trouve")
        self["ep_list"].setList(entries)

    def on_ok(self):
        s = self["ep_list"].getCurrent()
        if not s or not isinstance(s[1], dict): return
        ep = s[1]; self["lbl_status"].setText("  Lancement en cours...")
        if self._mode == "stalker":
            threading.Thread(target=lambda: self._stalker_resolve(ep), daemon=True).start()
        else:
            self._xtream_play(ep)

    def _stalker_resolve(self, ep):
        """Thread secondaire - NE PAS appeler session/nav directement."""
        import urllib.parse as _up
        url_final = None
        try:
            srv = self._srv; portal = srv.get("url",""); mac = srv.get("mac","00:1A:79:00:00:00")
            token = _stalker_token(portal, mac); cmd = ep.get("cmd","")
            req_url = portal.rstrip("/") + "/server/load.php?" + _up.urlencode({
                "type":"vod","action":"create_link","cmd":cmd,"series":"",
                "forced_storage":"undefined","disable_ad":"0","download":"0","JsHttpRequest":"1-xml"})
            req  = Request(req_url, headers={"User-Agent":"Mozilla/5.0",
                "Cookie":"mac=%s; stb_lang=en; timezone=Europe/Paris" % mac,
                "Authorization":"Bearer %s" % token})
            data = json.loads(urlopen(req, timeout=15).read().decode("utf-8", errors="replace"))
            link = data.get("js",{}).get("cmd","")
            if link:
                if link.startswith("ffmpeg "): link = link[7:].strip()
                if link.startswith(("http://","https://","rtsp://","rtmp://")): url_final = link
        except Exception as e:
            print("[Episodes] stalker resolve:", e)
        if not url_final:
            cmd = ep.get("cmd","")
            if cmd.startswith("ffmpeg "): cmd = cmd[7:].strip()
            if cmd.startswith(("http://","https://")): url_final = cmd
        ep_name = ep.get("name", ep.get("title","Episode"))
        if url_final: _eCall(self._open_player, url_final, ep_name)
        else: _eCall(self.session.open, MessageBox,
                     "Impossible de resoudre l URL de l episode.", MessageBox.TYPE_ERROR, 4)

    def _xtream_play(self, ep):
        srv = self._srv; base = srv.get("url","").rstrip("/")
        usr = srv.get("user",""); pwd = srv.get("pass","")
        ep_id = ep.get("id",""); ext = (ep.get("container_extension") or "mkv").strip().lstrip(".")
        url = "%s/series/%s/%s/%s.%s" % (base, usr, pwd, ep_id, ext)
        self._open_player(url, ep.get("title", ep.get("name","Episode")))

    def _open_player(self, url, ep_name):
        """Toujours dans le main thread (direct ou via _eCall)."""
        c = cfg(); key = c.player.value if c else "IPTV"
        stype = self._PLAYER_STYPES.get(key, 4097)
        title = "%s  S%s  -  %s" % (self._series_name, self._season_num, ep_name)
        self.session.openWithCallback(self._player_closed, UnionStreamPlayer,
                                      [{"num":1,"name":title,"url":url}], 0, "series", stype)

    def _player_closed(self, *args):
        self["lbl_status"].setText("  Lecture terminee. Choisissez un autre episode.")


class UnionStreamServers(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream IPTV - Servers">

                <!-- ===== BARRE DE TITRE ===== -->
                <widget name="title" position="center,20" size="500,50" font="Regular;50" foregroundColor="#ffffff"  text="Union Stream IPTV" />
                <widget name="subtitle" position="center,90" size="500,40" font="Regular;30" foregroundColor="#cccccc"  text="by Said M.S" />



                <!-- Menu gauche -->
                <widget name="lbl_menu"    position="10,200"     size="250,60"    font="Regular;34" foregroundColor="#4da6ff" backgroundColor="#111122" text="  Menu" />
                <widget name="mn_livetv"   position="10,290"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#1565c0" text="  Live TV" />
                <widget name="mn_vod"      position="10,380"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  VOD" />
                <widget name="mn_series"   position="10,470"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Series" />
                <widget name="mn_servers"  position="10,560"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Servers" />
                <widget name="mn_settings" position="10,650"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Setting" />
                
                 
                  
                   
                <!-- Titre section -->
                <widget name="lbl_section" position="300,200"  size="330,50" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#d4c00d" text="  Gestion des Servers" halign="center" />
                
                

                <!-- En-tetes tableau -->
                <widget name="hdr_hote"   position="350,290" size="1060,50" font="Regular;35" foregroundColor="#ffffff" backgroundColor="#333355" text="  Liste des Servers" halign="center" />
                

                <!-- Liste des Servers -->
                <widget name="server_list" position="350,350" size="1060,600" font="Regular;25" backgroundColor="#0d0d1a" foregroundColor="#ffffff" itemHeight="52" halign="center" />
                
                
                <!-- Barre de statut -->
                <widget name="lbl_status"  position="350,950" size="1060,40" font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#111122" text="  0 serveur(s) charge(s)" />

                <!-- Boutons action droite -->
                <widget name="btn_connect"  position="1600,275" size="250,60" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1565c0" text=" Connect" halign="center" />
                <widget name="btn_new"      position="1600,355" size="250,60" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#2e7d32" text=" Add" halign="center" />
                <widget name="btn_edit"     position="1600,435" size="250,60" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#b1d417" text=" Modifier" halign="center" />
                <widget name="btn_delete"   position="1600,515" size="250,60" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#b71c1c" text=" Delet" halign="center" />
                <widget name="btn_refresh"  position="1600,595" size="250,60" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#37474f" text=" Update" halign="center" />

                <!-- Barre de bas -->
                <widget name="lbl_active"  position="0,1030" size="1000,50" font="Regular;24" foregroundColor="#00cc00" backgroundColor="#0d0d1a" text="  Serveur actif : ---" />
            </screen>
        """
        self.setTitle("Union Stream - Servers")

        
        # ── Barre titre ──
        self["hdr_bg"]      = Label("")

        self["title"] = Label("Union Stream IPTV")
        self["subtitle"] = Label("by Said M.S")
        
        
        # Menu
        self["lbl_menu"]    = Label("  Menu")
        self["mn_livetv"]   = Label("  Live TV")
        self["mn_vod"]      = Label("  VOD")
        self["mn_series"]   = Label("  Series")
        self["mn_servers"]  = Label("  Servers")
        self["mn_settings"] = Label("  Setting")
        # Section
        self["lbl_section"] = Label("  Gestion des Servers")
        # En-tetes
        self["hdr_nom"]    = Label("  Nom")
        self["hdr_type"]   = Label("  Type")
        self["hdr_hote"]   = Label("  Hote")
        self["hdr_statut"] = Label("  Statut")
        # Liste
        self["server_list"] = MenuList([])
        self["lbl_status"]  = Label("  0 serveur(s) charge(s)")
        # Boutons
        self["btn_connect"] = Label("  Connect")
        self["btn_new"]     = Label("  + Add")
        self["btn_edit"]    = Label("  Edit")
        self["btn_delete"]  = Label("  Delet")
        self["btn_refresh"] = Label("  Update")
        # Bas
        self["lbl_active"]  = Label("  Serveur actif : ---")

        self._refresh_list()

        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions"],
            {
                "ok":     self.do_connect,
                "cancel": self.close,
                "up":     lambda: self["server_list"].up(),
                "down":   lambda: self["server_list"].down(),
                "green":  self.do_new,
                "yellow": self.do_edit,
                "red":    self.do_delete,
                "blue":   self.do_connect,
            }, -1)

    # ── Affichage ────────────────────────────────────────────────────────
    def _refresh_list(self):
        entries = []
        for s in SERVERS_DB:
            statut = "[Actif]  " if s["active"] else "[Inactif]"
            line = "%-26s  %-9s  %-42s  %s" % (
                s["name"][:26], s["type"], s["url"][:42], statut)
            entries.append((line, s))
        self["server_list"].setList(entries)
        self["lbl_status"].setText("  %d serveur(s) charge(s)" % len(SERVERS_DB))
        active = next((s for s in SERVERS_DB if s["active"]), None)
        self["lbl_active"].setText("  Serveur actif : %s (%s)" % (
            active["name"], active["type"]) if active else "  Serveur actif : ---")

    # ── Connect ────────────────────────────────────────────────────────
    def do_connect(self):
        s = self["server_list"].getCurrent()
        if not s:
            return
        chosen = s[1]
        # Activer le serveur choisi
        for sv in SERVERS_DB:
            sv["active"] = (sv is chosen)
        c = cfg()
        if c:
            c.server_url.value  = chosen["url"]
            c.server_type.value = chosen["type"]
            c.server_url.save()
            c.server_type.save()
        save_servers()
        self._refresh_list()

        # Lancer le pre-chargement des bouquets en arriere-plan
        self["lbl_status"].setText("  Connexion en cours...")
        name = chosen["name"]

        def on_loaded(ok, msg):
            status = "  %s : %s" % (name, msg) if ok else "  Erreur : %s" % msg
            self["lbl_status"].setText(status)
            self.session.open(MessageBox,
                "Serveur actif : %s\n%s" % (name, msg),
                MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR,
                timeout=4)

        load_server_data(on_done=on_loaded, cat_id="all")

    # ── Add ──────────────────────────────────────────────────────────
    def do_new(self):
        self.session.openWithCallback(self._new_done, UnionStreamServerEdit,
                                      {"name":"", "url":"", "type":"STALKER", "active":False},
                                      is_new=True)

    def _new_done(self, data):
        if data:
            SERVERS_DB.append(data)
            save_servers()
            self._refresh_list()

    # ── Edit ─────────────────────────────────────────────────────────
    def do_edit(self):
        s = self["server_list"].getCurrent()
        if not s:
            return
        self.session.openWithCallback(self._edit_done, UnionStreamServerEdit,
                                      dict(s[1]), is_new=False)

    def _edit_done(self, data):
        if data:
            s = self["server_list"].getCurrent()
            if s:
                idx = SERVERS_DB.index(s[1])
                SERVERS_DB[idx] = data
                save_servers()
                self._refresh_list()

    # ── Delet────────────────────────────────────────────────────────
    def do_delete(self):
        s = self["server_list"].getCurrent()
        if not s:
            return
        self.session.openWithCallback(self._delete_confirmed, MessageBox,
            "Deletle serveur :\n%s ?" % s[1]["name"],
            MessageBox.TYPE_YESNO)

    def _delete_confirmed(self, confirmed):
        if confirmed:
            s = self["server_list"].getCurrent()
            if s and s[1] in SERVERS_DB:
                SERVERS_DB.remove(s[1])
                save_servers()
                self._refresh_list()


# ── Ecran edition d'un serveur ────────────────────────────────────────────
class UnionStreamServerEdit(ConfigListScreen, Screen):
    def __init__(self, session, server, is_new=False):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="360,130" size="1200,760" title="Serveur">

                <!-- Fond -->
                <widget name="bg"           position="0,0"      size="1200,760"  backgroundColor="#0d1117" />

                <!-- Titre -->
                <widget name="ico_plus"     position="26,22"    size="56,56"     font="Regular;44" foregroundColor="#ffffff"  backgroundColor="#0d1117" text="+" halign="center" />
                <widget name="lbl_title"    position="94,22"    size="900,56"    font="Regular;40" foregroundColor="#ffffff"  backgroundColor="#0d1117" text="Add New Server" />

                <!-- Separateur haut -->
                <widget name="sep1"         position="0,96"     size="1200,2"    backgroundColor="#2a2a3a" />

                <!-- Zone config list -->
                <widget name="config"       position="20,108"   size="1160,490"  backgroundColor="#0d1117" foregroundColor="#ffffff" itemHeight="68" scrollbarMode="showNever" />

                <!-- Bandeau type actif -->
                <widget name="lbl_typeband" position="20,610"   size="1160,46"   font="Regular;26" foregroundColor="#00ccff"  backgroundColor="#111133" text="" halign="center" />

                <!-- Separateur bas -->
                <widget name="sep2"         position="0,666"    size="1200,2"    backgroundColor="#2a2a3a" />

                <!-- Boutons bas -->
                <widget name="btn_save"     position="26,680"   size="340,64"    font="Regular;30" foregroundColor="#ffffff"  backgroundColor="#2e7d32" text="+ Add Server" halign="center" />
                <widget name="btn_cancel"   position="386,680"  size="280,64"    font="Regular;30" foregroundColor="#ffffff"  backgroundColor="#b71c1c" text="x Cancel"     halign="center" />

            </screen>
        """
        self._is_new = is_new
        self._server = server

        title = "Add New Server" if is_new else "Edit : %s" % server.get("name", "")
        self.setTitle(title)

        self["bg"]           = Label("")
        self["ico_plus"]     = Label("+")
        self["lbl_title"]    = Label(title)
        self["sep1"]         = Label("")
        self["sep2"]         = Label("")
        self["lbl_typeband"] = Label("")
        self["btn_save"]     = Label("+ Add Server" if is_new else "Sauver")
        self["btn_cancel"]   = Label("x Cancel")

        # --- Config items ---
        from Components.config import ConfigText, ConfigSelection, ConfigPassword
        self._cfg_type  = ConfigSelection(
            choices=[("STALKER","Stalker Portal"), ("Xtream","Xtream Codes"), ("M3U","M3U Playlist")],
            default=server.get("type", "STALKER"))
        self._cfg_name  = ConfigText(default=server.get("name",     ""),  visible_width=36)
        self._cfg_url   = ConfigText(default=server.get("url",      ""),  visible_width=36)
        self._cfg_mac   = ConfigText(default=server.get("mac",      "00:1A:79:00:00:00"), visible_width=36)
        self._cfg_usr   = ConfigText(default=server.get("user",     ""),  visible_width=36)
        self._cfg_pass  = ConfigText(default=server.get("pass",     ""),  visible_width=36)
        self._cfg_m3u   = ConfigText(default=server.get("playlist", ""),  visible_width=36)

        ConfigListScreen.__init__(self, [], session=session)

        # Ecouter les changements de type
        self._cfg_type.addNotifier(self._on_type_changed, initial_call=False)

        self._rebuild_list()

        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "ok":     self.keyOK,
                "save":   self.keySave,
                "green":  self.keySave,
                "cancel": self.keyCancel,
                "red":    self.keyCancel,
            }, -2)

    # ─────────────────────────────────────────────────────────────────────
    def _on_type_changed(self, cfg):
        self._rebuild_list()

    def _rebuild_list(self):
        t = self._cfg_type.value

        # Bandeau descriptif
        banners = {
            "STALKER": "[ Stalker Portal ]   Server Name  |  Server URL  |  MAC Address",
            "Xtream":  "[ Xtream Codes   ]   Server Name  |  Server URL  |  Username  |  Password",
            "M3U":     "[ M3U Playlist   ]   Server Name  |  Server URL  |  Playlist URL",
        }
        self["lbl_typeband"].setText(banners.get(t, ""))

        # Entrees communes
        entries = [
            getConfigListEntry("  Type          ", self._cfg_type),
            getConfigListEntry("  Server Name   ", self._cfg_name),
            getConfigListEntry("  Server URL    ", self._cfg_url),
        ]

        # Entrees specifiques au type
        if t == "STALKER":
            entries.append(getConfigListEntry("  MAC Address   ", self._cfg_mac))
        elif t == "Xtream":
            entries.append(getConfigListEntry("  Username      ", self._cfg_usr))
            entries.append(getConfigListEntry("  Password      ", self._cfg_pass))
        elif t == "M3U":
            entries.append(getConfigListEntry("  Playlist URL  ", self._cfg_m3u))

        self["config"].setList(entries)

    # ─────────────────────────────────────────────────────────────────────
    def keyOK(self):
        cur = self["config"].getCurrent()
        if cur and cur[1] is self._cfg_type:
            # Cycle manuel STALKER → Xtream → M3U → STALKER
            order = ["STALKER", "Xtream", "M3U"]
            idx   = order.index(self._cfg_type.value)
            self._cfg_type.value = order[(idx + 1) % len(order)]
            self._rebuild_list()
        else:
            ConfigListScreen.keyOK(self)

    def keySave(self):
        name = self._cfg_name.value.strip()
        url  = self._cfg_url.value.strip()
        t    = self._cfg_type.value

        if not name:
            self.session.open(MessageBox, "Server Name est obligatoire.", MessageBox.TYPE_ERROR, timeout=3)
            return
        if not url:
            self.session.open(MessageBox, "Server URL est obligatoire.",  MessageBox.TYPE_ERROR, timeout=3)
            return

        result = {
            "name":   name,
            "url":    url,
            "type":   t,
            "active": self._server.get("active", False),
        }
        if t == "STALKER":
            result["mac"]      = self._cfg_mac.value.strip()
        elif t == "Xtream":
            result["user"]     = self._cfg_usr.value.strip()
            result["pass"]     = self._cfg_pass.value.strip()
        elif t == "M3U":
            result["playlist"] = self._cfg_m3u.value.strip()

        self.close(result)

    def keyCancel(self):
        self.close(None)


# ===================================================================
#  Écran Setting
# ===================================================================
class UnionStreamSettings(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
            <screen position="0,0" size="1920,1080" title="Union Stream IPTV - Setting">
                
                <!-- ===== BARRE DE TITRE ===== -->
                <widget name="title" position="center,20" size="500,50" font="Regular;50" foregroundColor="#ffffff"  text="Union Stream IPTV" />
                <widget name="subtitle" position="center,90" size="500,40" font="Regular;30" foregroundColor="#cccccc"  text="by Said M.S" />


                 <!-- ===== MENU GAUCHE ===== -->
                <widget name="lbl_menu"    position="10,200"     size="250,60"    font="Regular;34" foregroundColor="#4da6ff" backgroundColor="#111122" text="  Menu" />
                <widget name="mn_livetv"   position="10,290"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#1565c0" text="  Live TV" />
                <widget name="mn_vod"      position="10,380"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  VOD" />
                <widget name="mn_series"   position="10,470"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Series" />
                <widget name="mn_servers"  position="10,560"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Servers" />
                <widget name="mn_settings" position="10,650"     size="250,90"    font="Regular;34" foregroundColor="#ffffff" backgroundColor="#222226" text="  Setting" />

<!-- ===== ZONE PRINCIPALE ===== -->
                <!-- Titre section -->
                <widget name="lbl_section" position="300,200"   size="260,50"    font="Regular;30" foregroundColor="#ffffff" backgroundColor="#d4c00d" text="  Setting  " halign="center" />

                
                <!-- Cadre contenu -->
                <widget name="frame_bg"    position="290,290"  size="1560,470" backgroundColor="#0d0d1a" />

                <!-- ===== ONGLET PLAYER ===== -->
                <widget name="p_lbl_avail"   position="400,385" size="260,36"  font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Player available :" />
                

                <widget name="p_lbl_pref"    position="400,580" size="260,36"  font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Player prefere :" />
                <widget name="p_val_pref"    position="670,580" size="200,36"  font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="auto" />
                <widget name="p_lbl_pref_d"  position="900,580" size="400,36"  font="Regular;24" foregroundColor="#41c70c" backgroundColor="#0d0d1a" text="" />

                <widget name="p_lbl_timeout" position="400,635" size="260,36"  font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Timeout flux (sec) :" />
                <widget name="p_val_timeout" position="670,635" size="200,36"  font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="10" />

                <!-- ===== ONGLET CONNEXION (masque par defaut - taille 0) ===== -->
                <widget name="c_lbl_url"     position="200,230" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="URL / Portail :" />
                <widget name="c_val_url"     position="470,230" size="700,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="" />
                <widget name="c_lbl_type"    position="200,280" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Type serveur :" />
                <widget name="c_val_type"    position="470,280" size="200,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="STALKER" />
                <widget name="c_lbl_user"    position="200,330" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Utilisateur :" />
                <widget name="c_val_user"    position="470,330" size="400,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="" />
                <widget name="c_lbl_pass"    position="200,380" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Mot de passe :" />
                <widget name="c_val_pass"    position="470,380" size="400,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="" />
                <widget name="c_lbl_mac"     position="200,430" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Adresse MAC :" />
                <widget name="c_val_mac"     position="470,430" size="400,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="" />

                <!-- ===== ONGLET GENERAL (masque par defaut - taille 0) ===== -->
                <widget name="g_lbl_epg"     position="200,230" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="EPG active :" />
                <widget name="g_val_epg"     position="470,230" size="200,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="Oui" />
                <widget name="g_lbl_epgurl"  position="200,280" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="URL EPG :" />
                <widget name="g_val_epgurl"  position="470,280" size="700,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="" />
                <widget name="g_lbl_days"    position="200,330" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Jours EPG :" />
                <widget name="g_val_days"    position="470,330" size="100,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="3" />
                <widget name="g_lbl_theme"   position="200,380" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Theme :" />
                <widget name="g_val_theme"   position="470,380" size="200,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="blue" />
                <widget name="g_lbl_anim"    position="200,430" size="260,0"   font="Regular;24" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="Animations :" />
                <widget name="g_val_anim"    position="470,430" size="100,0"   font="Regular;24" foregroundColor="#ffffff" backgroundColor="#1a1a3a" text="Oui" />

                <!-- SePlayer Player (liste deroulante simulee) -->
                <widget name="player_list"   position="670,385" size="240,160" backgroundColor="#0d0673" foregroundColor="#ffffff" itemHeight="36" />

                <!-- ===== BOUTONS BAS ===== -->
                <widget name="btn_save"      position="400,900"  size="260,56"  font="Regular;30" foregroundColor="#ffffff" backgroundColor="#2e7d32" text=" Save" halign="center" />
                <widget name="btn_reset"     position="920,900"  size="260,56"  font="Regular;30" foregroundColor="#ffffff" backgroundColor="#1f15b0" text=" Restaurer defauts" halign="center" />
                
            <!-- Barre inferieure -->
                <widget name="lbl_active"    position="0,1030"   size="900,50"  font="Regular;22" foregroundColor="#00cc00" backgroundColor="#0d0d1a" text="  Serveur actif : ---" />
                <widget name="lbl_players"   position="1100,1030" size="800,50"  font="Regular;20" foregroundColor="#aaaaaa" backgroundColor="#0d0d1a" text="  DVB(1) | IPTV(4097) | GStreamer(5001) | ExtePlayer(5002)" />
            </screen>
        """
        _init_config()
        self.setTitle("Union Stream - Setting")

        # Etat onglet actif : 0=Player, 1=Connexion, 2=General
        self._tab = 0
        # Etat focus zone : "tabs" | "player_list" | "fields"
        self._focus = "tabs"

        # Player available
        self._players     = ["DVB","IPTV","GStreamer","ExtePlayer"]
        self._player_idx  = 0

        # ── Barre titre ──
        self["hdr_bg"]      = Label("")

        self["title"] = Label("Union Stream IPTV")
        self["subtitle"] = Label("by Said M.S")
        
        
        # Menu gauche
        self["lbl_menu"]     = Label("  Menu")
        self["mn_livetv"]    = Label("  Live TV")
        self["mn_vod"]       = Label("  VOD")
        self["mn_series"]    = Label("  Series")
        self["mn_servers"]   = Label("  Servers")
        self["mn_settings"]  = Label("  Setting")
        # Section
        self["lbl_section"]  = Label("  Setting")
        # Onglets
        self["tab_player"]   = Label("  Player")
        self["tab_conn"]     = Label("  Connexion")
        self["tab_gen"]      = Label("  General")
        # Cadre
        self["frame_bg"]     = Label("")
        # Onglet Player
        self["p_lbl_avail"]  = Label("Player available :")
        self["p_lbl_dvb"]  = Label("DVB (1)")
        self["p_lbl_sep1"]   = Label(" |")
        self["p_lbl_gst"]  = Label("GStreamer (5001)")
        self["p_lbl_sep2"]   = Label(" |")
        self["p_lbl_wmp"]    = Label("ExtePlayer (5002)")
        self["p_lbl_pref"]   = Label("Player prefere :")
        self["p_val_pref"]   = Label("auto")
        self["p_lbl_pref_d"] = Label("")
        self["p_lbl_timeout"]= Label("Timeout flux (sec) :")
        self["p_val_timeout"]= Label("10")
        # Onglet Connexion
        self["c_lbl_url"]    = Label("URL / Portail :")
        self["c_val_url"]    = Label("")
        self["c_lbl_type"]   = Label("Type serveur :")
        self["c_val_type"]   = Label("STALKER")
        self["c_lbl_user"]   = Label("Utilisateur :")
        self["c_val_user"]   = Label("")
        self["c_lbl_pass"]   = Label("Mot de passe :")
        self["c_val_pass"]   = Label("")
        self["c_lbl_mac"]    = Label("Adresse MAC :")
        self["c_val_mac"]    = Label("")
        # Onglet General
        self["g_lbl_epg"]    = Label("EPG active :")
        self["g_val_epg"]    = Label("Oui")
        self["g_lbl_epgurl"] = Label("URL EPG :")
        self["g_val_epgurl"] = Label("")
        self["g_lbl_days"]   = Label("Jours EPG :")
        self["g_val_days"]   = Label("3")
        self["g_lbl_theme"]  = Label("Theme :")
        self["g_val_theme"]  = Label("blue")
        self["g_lbl_anim"]   = Label("Animations :")
        self["g_val_anim"]   = Label("Oui")
        # Liste Players
        self["player_list"]  = MenuList(self._player_entries())
        # Boutons bas
        self["btn_save"]     = Label("  Save")
        self["btn_reset"]    = Label("  Restaurer defauts")
        # Barre inferieure
        self["lbl_active"]   = Label("  Serveur actif : ---")
        self["lbl_players"]  = Label("  DVB (1) | IPTV (4097) | GStreamer (5001) | ExtePlayer (5002)")

        self._load_values()
        self._update_active_server()
        self._update_tabs()

        self["actions"] = ActionMap(
            ["OkCancelActions","DirectionActions","ColorActions"],
            {
                "ok":     self.on_ok,
                "cancel": self.close,
                "up":     self.on_up,
                "down":   self.on_down,
                "left":   self.on_left,
                "right":  self.on_right,
                "green":  self.do_save,
                "red":    self.do_reset,
            }, -1)

    # ── Serveur actif ─────────────────────────────────────────────────────
    def _update_active_server(self):
        active = next((s for s in SERVERS_DB if s["active"]), None)
        if active:
            self["lbl_active"].setText("  Serveur actif : %s (%s)" % (active["name"], active["type"]))

    # ── Positionne la liste sur l'index voulu ─────────────────────────────
    def _set_player_list_index(self, idx):
        """MenuList n'a pas de setIndex — on remet la liste et on scrolle."""
        self["player_list"].setList(self._player_entries())
        # Descendre jusqu'a l'index souhaite
        for _ in range(idx):
            self["player_list"].down()

    def _player_entries(self):
        labels = {
            "DVB":        "DVB           (type 1)",
            "IPTV":       "IPTV          (type 4097)",
            "GStreamer":  "GStreamer      (type 5001)",
            "ExtePlayer": "ExtePlayer     (type 5002)",
        }
        return [(labels.get(p, p), p) for p in self._players]

    # ── Charge les valeurs de config ──────────────────────────────────────
    def _load_values(self):
        c = cfg()
        if not c:
            return
        # Player
        try:
            idx = self._players.index(c.player.value)
            self._player_idx = idx
        except ValueError:
            self._player_idx = 0
        self["p_val_pref"].setText(self._players[self._player_idx])
        self["p_val_timeout"].setText(str(c.buffer_time.value))
        self._set_player_list_index(self._player_idx)
        # Connexion
        self["c_val_url"].setText(c.server_url.value)
        self["c_val_type"].setText(c.server_type.value)
        self["c_val_user"].setText(c.username.value)
        self["c_val_pass"].setText("*" * len(c.password.value))
        self["c_val_mac"].setText(c.mac_address.value)
        # General
        self["g_val_epg"].setText("Oui" if c.epg_enabled.value else "Non")
        self["g_val_epgurl"].setText(c.epg_url.value)
        self["g_val_days"].setText(str(c.epg_days.value))
        self["g_val_theme"].setText(c.theme.value)
        self["g_val_anim"].setText("Oui" if c.animations.value else "Non")

    # ── Mise a jour visuelle des onglets ──────────────────────────────────
    def _update_tabs(self):
        tabs = ["tab_player","tab_conn","tab_gen"]
        labels = ["  Player","  Connexion","  General"]
        for i, (wname, lbl) in enumerate(zip(tabs, labels)):
            if i == self._tab:
                self[wname].setText("> " + lbl.strip())
            else:
                self[wname].setText(lbl)
        # Met a jour la description du Player selectionne
        descs = {
            "DVB":        "DVB natif Enigma2  (type 1)",
            "IPTV":       "IPTV service natif (type 4097)",
            "GStreamer":  "GStreamer pipeline  (type 5001)",
            "ExtePlayer": "ExtePlayer externe  (type 5002)",
        }
        sel = self._players[self._player_idx]
        self["p_val_pref"].setText(sel)
        self["p_lbl_pref_d"].setText(descs.get(sel, ""))

    # ── Navigation ────────────────────────────────────────────────────────
    def on_left(self):
        if self._focus == "player_list":
            self._focus = "tabs"
        elif self._focus == "tabs" and self._tab > 0:
            self._tab -= 1
            self._update_tabs()

    def on_right(self):
        if self._focus == "tabs" and self._tab < 2:
            self._tab += 1
            self._update_tabs()
        elif self._focus == "tabs" and self._tab == 0:
            self._focus = "player_list"

    def on_up(self):
        if self._focus == "player_list":
            self["player_list"].up()
            s = self["player_list"].getCurrent()
            if s:
                self._player_idx = self._players.index(s[1])
                self._update_tabs()

    def on_down(self):
        if self._focus == "player_list":
            self["player_list"].down()
            s = self["player_list"].getCurrent()
            if s:
                self._player_idx = self._players.index(s[1])
                self._update_tabs()
        elif self._focus == "tabs":
            self._focus = "player_list"

    def on_ok(self):
        if self._focus == "tabs":
            self._focus = "player_list" if self._tab == 0 else "fields"
        elif self._focus == "player_list":
            s = self["player_list"].getCurrent()
            if s:
                self._player_idx = self._players.index(s[1])
                self._update_tabs()

    # ── Save ───────────────────────────────────────────────────────
    def do_save(self):
        c = cfg()
        if c:
            c.player.value = self._players[self._player_idx]
            c.player.save()
            config.plugins.UnionStream.save()
        self.session.open(MessageBox, "Setting sauvegardes.", MessageBox.TYPE_INFO, timeout=3)
        self.close()

    # ── Restaurer defauts ─────────────────────────────────────────────────
    def do_reset(self):
        self._player_idx = 0
        self._set_player_list_index(0)
        self._update_tabs()
        self.session.open(MessageBox, "Valeurs par defaut restaurees.", MessageBox.TYPE_INFO, timeout=2)


def main(session, **kwargs):
    session.open(UnionStreamMain)

def autostart(reason, **kwargs):
    if reason == 0:
        UnionStreamService.start()
    elif reason == 1:
        UnionStreamService.stop()

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Union Stream IPTV",
            description="Live TV, VOD, Series",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main,
        ),
        PluginDescriptor(
            name="Union Stream IPTV",
            description="Ouvrir Union Stream IPTV",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main,
        ),
        PluginDescriptor(
            name="UnionStream",
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart,
        ),
    ]